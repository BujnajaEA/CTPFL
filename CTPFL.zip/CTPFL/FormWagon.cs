﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTPFL
{
    public partial class FormWagon : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        string connectionString = @"Data Source=DESKTOP-L5BOSMO;initial catalog=D_CTPFL;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;";
        string sql = "select * from Вагон";

        private FormMain _fmain;

        public FormWagon(FormMain fmain)
        {
            InitializeComponent();

            _fmain = fmain;

            dataGridView_Wagon.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Wagon.DataSource = ds.Tables[0];
                dataGridView_Wagon.Columns["Код_вагона"].ReadOnly = true;
            }
        }

        private void FormWagon_Load(object sender, EventArgs e)
        {

        }

        private void button_Back_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _fmain.Visible = true;
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            string wagonModel = textBox_WagonModel.Text;
            string wagonCapacity = textBox_WagonCapacity.Text;
            string sideHeight = textBox_SideHeight.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdGetLastID = new SqlCommand("select TOP 1 [Код_вагона] from Вагон order by [Код_вагона] DESC", connection);
                int lastID = (int)cmdGetLastID.ExecuteScalar();

                SqlCommand cmdAddWagon = new SqlCommand("insert into Вагон" +
                    "([Код_вагона], [Модель_вагона], [Грузоподъемность, т], [Высота_борта, м])" +
                    $"values('{lastID + 1}','{wagonModel}','{wagonCapacity}','{sideHeight}')", connection);
                cmdAddWagon.ExecuteNonQuery();
                MessageBox.Show("Вагон добавлен");
            }
            textBox_WagonModel.Clear();
            textBox_WagonCapacity.Clear();
            textBox_SideHeight.Clear();

            dataGridView_Wagon.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Wagon.DataSource = ds.Tables[0];
                dataGridView_Wagon.Columns["Код_вагона"].ReadOnly = true;
            }
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            string wagonModel = textBox_WagonModel.Text;
            string wagonCapacity = textBox_WagonCapacity.Text;
            string sideHeight = textBox_SideHeight.Text;

            string selectedWagonID = dataGridView_Wagon.CurrentCell.Value.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdEditWagon = new SqlCommand("update Вагон" +
                $" set [Модель_вагона] = '{wagonModel}', [Грузоподъемность, т] = '{wagonCapacity}', [Высота_борта, м] = '{sideHeight}'" +
                $" where [Код_вагона] = '{selectedWagonID}'", connection);
                cmdEditWagon.ExecuteNonQuery();
                MessageBox.Show("Данные выбранного вагона отредактированы");
            }

            textBox_WagonModel.Clear();
            textBox_WagonCapacity.Clear();
            textBox_SideHeight.Clear();

            dataGridView_Wagon.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Wagon.DataSource = ds.Tables[0];
                dataGridView_Wagon.Columns["Код_вагона"].ReadOnly = true;
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            string selectedWagonID = dataGridView_Wagon.CurrentCell.Value.ToString();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdDeleteWagon = new SqlCommand($"delete from Вагон where [Код_вагона] = {selectedWagonID}", connection);
                cmdDeleteWagon.ExecuteNonQuery();
                MessageBox.Show($"Вы удалили вагон с кодом {selectedWagonID}.");
            }

            dataGridView_Wagon.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Wagon.DataSource = ds.Tables[0];
                dataGridView_Wagon.Columns["Код_вагона"].ReadOnly = true;
            }
        }

        private void groupBox_Buttons_Enter(object sender, EventArgs e)
        {

        }
    }
}
