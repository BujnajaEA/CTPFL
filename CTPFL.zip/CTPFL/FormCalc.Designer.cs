﻿namespace CTPFL
{
    partial class FormCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCalc));
            this.groupBox_Buttons = new System.Windows.Forms.GroupBox();
            this.textBox_WagonID = new System.Windows.Forms.TextBox();
            this.textBox_LoaderID = new System.Windows.Forms.TextBox();
            this.button_NewCalc = new System.Windows.Forms.Button();
            this.button_SaveReport = new System.Windows.Forms.Button();
            this.button_Clear = new System.Windows.Forms.Button();
            this.button_GoCalc = new System.Windows.Forms.Button();
            this.button_Back = new System.Windows.Forms.Button();
            this.groupBox_RollingStock = new System.Windows.Forms.GroupBox();
            this.textBox_SideHeight = new System.Windows.Forms.TextBox();
            this.label_SideHeight = new System.Windows.Forms.Label();
            this.textBox_NumberOfWagons = new System.Windows.Forms.TextBox();
            this.label_NumberOfWagons = new System.Windows.Forms.Label();
            this.textBox_WagonCapacity = new System.Windows.Forms.TextBox();
            this.label_WagonCapacity = new System.Windows.Forms.Label();
            this.comboBox_WagonModel = new System.Windows.Forms.ComboBox();
            this.label_WagonModel = new System.Windows.Forms.Label();
            this.groupBox_Loader = new System.Windows.Forms.GroupBox();
            this.textBox_AverageDumpingTimeFromTheBucket = new System.Windows.Forms.TextBox();
            this.label_AverageDumpingTimeFromTheBucket = new System.Windows.Forms.Label();
            this.textBox_AverageBucketFillingTime = new System.Windows.Forms.TextBox();
            this.label_AverageBucketFillingTime = new System.Windows.Forms.Label();
            this.textBox_BucketSpeedWithLoad = new System.Windows.Forms.TextBox();
            this.label_BucketSpeedWithLoad = new System.Windows.Forms.Label();
            this.textBox_BucketSpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_BucketSpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_BucketTipTime = new System.Windows.Forms.TextBox();
            this.label_BucketTipTime = new System.Windows.Forms.Label();
            this.textBox_LoadedSpeed = new System.Windows.Forms.TextBox();
            this.label_LoadedSpeed = new System.Windows.Forms.Label();
            this.textBox_SpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_SpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_BucketVolume = new System.Windows.Forms.TextBox();
            this.label_BucketVolume = new System.Windows.Forms.Label();
            this.textBox_LoaderCapacity = new System.Windows.Forms.TextBox();
            this.label_LoaderCapacity = new System.Windows.Forms.Label();
            this.comboBox_LoaderBrand = new System.Windows.Forms.ComboBox();
            this.label_LoaderBrand = new System.Windows.Forms.Label();
            this.groupBox_Report = new System.Windows.Forms.GroupBox();
            this.textBox_ReportName = new System.Windows.Forms.TextBox();
            this.label_ReportName = new System.Windows.Forms.Label();
            this.groupBox_Distance = new System.Windows.Forms.GroupBox();
            this.textBox_L5 = new System.Windows.Forms.TextBox();
            this.label_L5 = new System.Windows.Forms.Label();
            this.textBox_L4 = new System.Windows.Forms.TextBox();
            this.label_L4 = new System.Windows.Forms.Label();
            this.textBox_L3 = new System.Windows.Forms.TextBox();
            this.label_L3 = new System.Windows.Forms.Label();
            this.textBox_L2 = new System.Windows.Forms.TextBox();
            this.label_L2 = new System.Windows.Forms.Label();
            this.groupBox_Result = new System.Windows.Forms.GroupBox();
            this.textBox_ResSideHeight = new System.Windows.Forms.TextBox();
            this.label_ResSideHeight = new System.Windows.Forms.Label();
            this.textBox_TrainServiceTime = new System.Windows.Forms.TextBox();
            this.label_TrainServiceTime = new System.Windows.Forms.Label();
            this.textBox_WagonServiceTime = new System.Windows.Forms.TextBox();
            this.label_WagonServiceTime = new System.Windows.Forms.Label();
            this.textBox_LoaderPerformance = new System.Windows.Forms.TextBox();
            this.label_LoaderPerformance = new System.Windows.Forms.Label();
            this.textBox_TechnicalLoaderPerformance = new System.Windows.Forms.TextBox();
            this.label_TechnicalLoaderPerformance = new System.Windows.Forms.Label();
            this.textBox_LoaderCycle = new System.Windows.Forms.TextBox();
            this.label_LoaderCycle = new System.Windows.Forms.Label();
            this.textBox_ResL5 = new System.Windows.Forms.TextBox();
            this.label_ResL5 = new System.Windows.Forms.Label();
            this.textBox_ResL4 = new System.Windows.Forms.TextBox();
            this.label_ResL4 = new System.Windows.Forms.Label();
            this.textBox_ResL3 = new System.Windows.Forms.TextBox();
            this.label_ResL3 = new System.Windows.Forms.Label();
            this.textBox_ResL2 = new System.Windows.Forms.TextBox();
            this.label_ResL2 = new System.Windows.Forms.Label();
            this.textBox_ResAverageDumpingTimeFromTheBucket = new System.Windows.Forms.TextBox();
            this.label_ResAverageDumpingTimeFromTheBucket = new System.Windows.Forms.Label();
            this.textBox_ResAverageBucketFillingTime = new System.Windows.Forms.TextBox();
            this.label_ResAverageBucketFillingTime = new System.Windows.Forms.Label();
            this.textBox_ResBucketSpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_ResBucketSpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_ResBucketSpeedWithLoad = new System.Windows.Forms.TextBox();
            this.label_ResBucketSpeedWithLoad = new System.Windows.Forms.Label();
            this.textBox_ResBucketTipTime = new System.Windows.Forms.TextBox();
            this.label_ResBucketTipTime = new System.Windows.Forms.Label();
            this.textBox_ResLoadedSpeed = new System.Windows.Forms.TextBox();
            this.label_ResLoadedSpeed = new System.Windows.Forms.Label();
            this.textBox_ResSpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_ResSpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_ResBucketVolume = new System.Windows.Forms.TextBox();
            this.label_ResBucketVolume = new System.Windows.Forms.Label();
            this.textBox_ResLoaderCapacity = new System.Windows.Forms.TextBox();
            this.label_ResLoaderCapacity = new System.Windows.Forms.Label();
            this.textBox_ResLoaderBrand = new System.Windows.Forms.TextBox();
            this.label_ResLoaderBrand = new System.Windows.Forms.Label();
            this.textBox_ResWagonCapacity = new System.Windows.Forms.TextBox();
            this.label_ResNumberOfWagons = new System.Windows.Forms.Label();
            this.textBox_ResNumberOfWagons = new System.Windows.Forms.TextBox();
            this.label_ResWagonCapacity = new System.Windows.Forms.Label();
            this.textBox_ResWagonModel = new System.Windows.Forms.TextBox();
            this.label_ResWagonModel = new System.Windows.Forms.Label();
            this.textBox_ResReportName = new System.Windows.Forms.TextBox();
            this.label_ResReportName = new System.Windows.Forms.Label();
            this.groupBox_Buttons.SuspendLayout();
            this.groupBox_RollingStock.SuspendLayout();
            this.groupBox_Loader.SuspendLayout();
            this.groupBox_Report.SuspendLayout();
            this.groupBox_Distance.SuspendLayout();
            this.groupBox_Result.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Buttons
            // 
            this.groupBox_Buttons.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox_Buttons.Controls.Add(this.textBox_WagonID);
            this.groupBox_Buttons.Controls.Add(this.textBox_LoaderID);
            this.groupBox_Buttons.Controls.Add(this.button_NewCalc);
            this.groupBox_Buttons.Controls.Add(this.button_SaveReport);
            this.groupBox_Buttons.Controls.Add(this.button_Clear);
            this.groupBox_Buttons.Controls.Add(this.button_GoCalc);
            this.groupBox_Buttons.Controls.Add(this.button_Back);
            this.groupBox_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox_Buttons.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Buttons.Location = new System.Drawing.Point(1332, 0);
            this.groupBox_Buttons.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Name = "groupBox_Buttons";
            this.groupBox_Buttons.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Size = new System.Drawing.Size(250, 839);
            this.groupBox_Buttons.TabIndex = 1;
            this.groupBox_Buttons.TabStop = false;
            this.groupBox_Buttons.Text = "Выберите действие";
            // 
            // textBox_WagonID
            // 
            this.textBox_WagonID.Location = new System.Drawing.Point(99, 990);
            this.textBox_WagonID.Name = "textBox_WagonID";
            this.textBox_WagonID.Size = new System.Drawing.Size(85, 32);
            this.textBox_WagonID.TabIndex = 12;
            this.textBox_WagonID.Visible = false;
            // 
            // textBox_LoaderID
            // 
            this.textBox_LoaderID.Location = new System.Drawing.Point(8, 990);
            this.textBox_LoaderID.Name = "textBox_LoaderID";
            this.textBox_LoaderID.Size = new System.Drawing.Size(85, 32);
            this.textBox_LoaderID.TabIndex = 11;
            this.textBox_LoaderID.Visible = false;
            // 
            // button_NewCalc
            // 
            this.button_NewCalc.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_NewCalc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_NewCalc.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_NewCalc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_NewCalc.Location = new System.Drawing.Point(5, 170);
            this.button_NewCalc.Margin = new System.Windows.Forms.Padding(0);
            this.button_NewCalc.Name = "button_NewCalc";
            this.button_NewCalc.Size = new System.Drawing.Size(240, 35);
            this.button_NewCalc.TabIndex = 4;
            this.button_NewCalc.Text = "Новый расчет";
            this.button_NewCalc.UseVisualStyleBackColor = false;
            this.button_NewCalc.Visible = false;
            this.button_NewCalc.Click += new System.EventHandler(this.button_NewCalc_Click);
            // 
            // button_SaveReport
            // 
            this.button_SaveReport.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_SaveReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_SaveReport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_SaveReport.Location = new System.Drawing.Point(5, 135);
            this.button_SaveReport.Margin = new System.Windows.Forms.Padding(0);
            this.button_SaveReport.Name = "button_SaveReport";
            this.button_SaveReport.Size = new System.Drawing.Size(240, 35);
            this.button_SaveReport.TabIndex = 3;
            this.button_SaveReport.Text = "Сохранить отчет";
            this.button_SaveReport.UseVisualStyleBackColor = false;
            this.button_SaveReport.Visible = false;
            this.button_SaveReport.Click += new System.EventHandler(this.button_SaveReport_Click);
            // 
            // button_Clear
            // 
            this.button_Clear.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Clear.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Clear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Clear.Location = new System.Drawing.Point(5, 100);
            this.button_Clear.Margin = new System.Windows.Forms.Padding(0);
            this.button_Clear.Name = "button_Clear";
            this.button_Clear.Size = new System.Drawing.Size(240, 35);
            this.button_Clear.TabIndex = 2;
            this.button_Clear.Text = "Очистить";
            this.button_Clear.UseVisualStyleBackColor = false;
            this.button_Clear.Click += new System.EventHandler(this.button_Clear_Click);
            // 
            // button_GoCalc
            // 
            this.button_GoCalc.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_GoCalc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_GoCalc.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_GoCalc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_GoCalc.Location = new System.Drawing.Point(5, 65);
            this.button_GoCalc.Margin = new System.Windows.Forms.Padding(0);
            this.button_GoCalc.Name = "button_GoCalc";
            this.button_GoCalc.Size = new System.Drawing.Size(240, 35);
            this.button_GoCalc.TabIndex = 1;
            this.button_GoCalc.Text = "Рассчитать";
            this.button_GoCalc.UseVisualStyleBackColor = false;
            this.button_GoCalc.Click += new System.EventHandler(this.button_GoCalc_Click);
            // 
            // button_Back
            // 
            this.button_Back.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Back.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Back.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Back.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Back.Location = new System.Drawing.Point(5, 30);
            this.button_Back.Margin = new System.Windows.Forms.Padding(0);
            this.button_Back.Name = "button_Back";
            this.button_Back.Size = new System.Drawing.Size(240, 35);
            this.button_Back.TabIndex = 0;
            this.button_Back.Text = "Вернуться в меню";
            this.button_Back.UseVisualStyleBackColor = false;
            this.button_Back.Click += new System.EventHandler(this.button_Back_Click);
            // 
            // groupBox_RollingStock
            // 
            this.groupBox_RollingStock.Controls.Add(this.textBox_SideHeight);
            this.groupBox_RollingStock.Controls.Add(this.label_SideHeight);
            this.groupBox_RollingStock.Controls.Add(this.textBox_NumberOfWagons);
            this.groupBox_RollingStock.Controls.Add(this.label_NumberOfWagons);
            this.groupBox_RollingStock.Controls.Add(this.textBox_WagonCapacity);
            this.groupBox_RollingStock.Controls.Add(this.label_WagonCapacity);
            this.groupBox_RollingStock.Controls.Add(this.comboBox_WagonModel);
            this.groupBox_RollingStock.Controls.Add(this.label_WagonModel);
            this.groupBox_RollingStock.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_RollingStock.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_RollingStock.Location = new System.Drawing.Point(0, 0);
            this.groupBox_RollingStock.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_RollingStock.Name = "groupBox_RollingStock";
            this.groupBox_RollingStock.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_RollingStock.Size = new System.Drawing.Size(1332, 82);
            this.groupBox_RollingStock.TabIndex = 2;
            this.groupBox_RollingStock.TabStop = false;
            this.groupBox_RollingStock.Text = "Введите данные подвижного состава";
            // 
            // textBox_SideHeight
            // 
            this.textBox_SideHeight.Location = new System.Drawing.Point(774, 29);
            this.textBox_SideHeight.Name = "textBox_SideHeight";
            this.textBox_SideHeight.ReadOnly = true;
            this.textBox_SideHeight.Size = new System.Drawing.Size(99, 29);
            this.textBox_SideHeight.TabIndex = 7;
            // 
            // label_SideHeight
            // 
            this.label_SideHeight.AutoSize = true;
            this.label_SideHeight.Location = new System.Drawing.Point(625, 32);
            this.label_SideHeight.Name = "label_SideHeight";
            this.label_SideHeight.Size = new System.Drawing.Size(143, 21);
            this.label_SideHeight.TabIndex = 6;
            this.label_SideHeight.Text = "Высота борта, м";
            // 
            // textBox_NumberOfWagons
            // 
            this.textBox_NumberOfWagons.Location = new System.Drawing.Point(1095, 29);
            this.textBox_NumberOfWagons.Name = "textBox_NumberOfWagons";
            this.textBox_NumberOfWagons.Size = new System.Drawing.Size(89, 29);
            this.textBox_NumberOfWagons.TabIndex = 5;
            // 
            // label_NumberOfWagons
            // 
            this.label_NumberOfWagons.AutoSize = true;
            this.label_NumberOfWagons.Location = new System.Drawing.Point(879, 32);
            this.label_NumberOfWagons.Name = "label_NumberOfWagons";
            this.label_NumberOfWagons.Size = new System.Drawing.Size(210, 21);
            this.label_NumberOfWagons.TabIndex = 4;
            this.label_NumberOfWagons.Text = "Количество вагонов, шт:";
            // 
            // textBox_WagonCapacity
            // 
            this.textBox_WagonCapacity.Location = new System.Drawing.Point(514, 29);
            this.textBox_WagonCapacity.Name = "textBox_WagonCapacity";
            this.textBox_WagonCapacity.ReadOnly = true;
            this.textBox_WagonCapacity.Size = new System.Drawing.Size(105, 29);
            this.textBox_WagonCapacity.TabIndex = 3;
            // 
            // label_WagonCapacity
            // 
            this.label_WagonCapacity.AutoSize = true;
            this.label_WagonCapacity.Location = new System.Drawing.Point(328, 32);
            this.label_WagonCapacity.Name = "label_WagonCapacity";
            this.label_WagonCapacity.Size = new System.Drawing.Size(180, 21);
            this.label_WagonCapacity.TabIndex = 2;
            this.label_WagonCapacity.Text = "Грузоподъемность, т";
            // 
            // comboBox_WagonModel
            // 
            this.comboBox_WagonModel.FormattingEnabled = true;
            this.comboBox_WagonModel.Items.AddRange(new object[] {
            "12-132-02",
            "12-175",
            "12-1302",
            "12-9085"});
            this.comboBox_WagonModel.Location = new System.Drawing.Point(152, 29);
            this.comboBox_WagonModel.Name = "comboBox_WagonModel";
            this.comboBox_WagonModel.Size = new System.Drawing.Size(170, 29);
            this.comboBox_WagonModel.TabIndex = 1;
            this.comboBox_WagonModel.SelectedIndexChanged += new System.EventHandler(this.comboBox_WagonModel_SelectedIndexChanged);
            // 
            // label_WagonModel
            // 
            this.label_WagonModel.AutoSize = true;
            this.label_WagonModel.Location = new System.Drawing.Point(17, 32);
            this.label_WagonModel.Name = "label_WagonModel";
            this.label_WagonModel.Size = new System.Drawing.Size(129, 21);
            this.label_WagonModel.TabIndex = 0;
            this.label_WagonModel.Text = "Модель вагона";
            // 
            // groupBox_Loader
            // 
            this.groupBox_Loader.Controls.Add(this.textBox_AverageDumpingTimeFromTheBucket);
            this.groupBox_Loader.Controls.Add(this.label_AverageDumpingTimeFromTheBucket);
            this.groupBox_Loader.Controls.Add(this.textBox_AverageBucketFillingTime);
            this.groupBox_Loader.Controls.Add(this.label_AverageBucketFillingTime);
            this.groupBox_Loader.Controls.Add(this.textBox_BucketSpeedWithLoad);
            this.groupBox_Loader.Controls.Add(this.label_BucketSpeedWithLoad);
            this.groupBox_Loader.Controls.Add(this.textBox_BucketSpeedWithoutLoad);
            this.groupBox_Loader.Controls.Add(this.label_BucketSpeedWithoutLoad);
            this.groupBox_Loader.Controls.Add(this.textBox_BucketTipTime);
            this.groupBox_Loader.Controls.Add(this.label_BucketTipTime);
            this.groupBox_Loader.Controls.Add(this.textBox_LoadedSpeed);
            this.groupBox_Loader.Controls.Add(this.label_LoadedSpeed);
            this.groupBox_Loader.Controls.Add(this.textBox_SpeedWithoutLoad);
            this.groupBox_Loader.Controls.Add(this.label_SpeedWithoutLoad);
            this.groupBox_Loader.Controls.Add(this.textBox_BucketVolume);
            this.groupBox_Loader.Controls.Add(this.label_BucketVolume);
            this.groupBox_Loader.Controls.Add(this.textBox_LoaderCapacity);
            this.groupBox_Loader.Controls.Add(this.label_LoaderCapacity);
            this.groupBox_Loader.Controls.Add(this.comboBox_LoaderBrand);
            this.groupBox_Loader.Controls.Add(this.label_LoaderBrand);
            this.groupBox_Loader.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Loader.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Loader.Location = new System.Drawing.Point(0, 82);
            this.groupBox_Loader.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Loader.Name = "groupBox_Loader";
            this.groupBox_Loader.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_Loader.Size = new System.Drawing.Size(1332, 154);
            this.groupBox_Loader.TabIndex = 3;
            this.groupBox_Loader.TabStop = false;
            this.groupBox_Loader.Text = "Введите данные погрузчика";
            // 
            // textBox_AverageDumpingTimeFromTheBucket
            // 
            this.textBox_AverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(1143, 110);
            this.textBox_AverageDumpingTimeFromTheBucket.Name = "textBox_AverageDumpingTimeFromTheBucket";
            this.textBox_AverageDumpingTimeFromTheBucket.ReadOnly = true;
            this.textBox_AverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(85, 29);
            this.textBox_AverageDumpingTimeFromTheBucket.TabIndex = 22;
            // 
            // label_AverageDumpingTimeFromTheBucket
            // 
            this.label_AverageDumpingTimeFromTheBucket.AutoSize = true;
            this.label_AverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(767, 113);
            this.label_AverageDumpingTimeFromTheBucket.Name = "label_AverageDumpingTimeFromTheBucket";
            this.label_AverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(370, 21);
            this.label_AverageDumpingTimeFromTheBucket.TabIndex = 21;
            this.label_AverageDumpingTimeFromTheBucket.Text = "Среднее время высыпания груза из ковша, с";
            // 
            // textBox_AverageBucketFillingTime
            // 
            this.textBox_AverageBucketFillingTime.Location = new System.Drawing.Point(676, 110);
            this.textBox_AverageBucketFillingTime.Name = "textBox_AverageBucketFillingTime";
            this.textBox_AverageBucketFillingTime.ReadOnly = true;
            this.textBox_AverageBucketFillingTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_AverageBucketFillingTime.TabIndex = 20;
            // 
            // label_AverageBucketFillingTime
            // 
            this.label_AverageBucketFillingTime.AutoSize = true;
            this.label_AverageBucketFillingTime.Location = new System.Drawing.Point(370, 113);
            this.label_AverageBucketFillingTime.Name = "label_AverageBucketFillingTime";
            this.label_AverageBucketFillingTime.Size = new System.Drawing.Size(300, 21);
            this.label_AverageBucketFillingTime.TabIndex = 19;
            this.label_AverageBucketFillingTime.Text = "Среднее время заполнения ковша, с";
            // 
            // textBox_BucketSpeedWithLoad
            // 
            this.textBox_BucketSpeedWithLoad.Location = new System.Drawing.Point(957, 72);
            this.textBox_BucketSpeedWithLoad.Name = "textBox_BucketSpeedWithLoad";
            this.textBox_BucketSpeedWithLoad.ReadOnly = true;
            this.textBox_BucketSpeedWithLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketSpeedWithLoad.TabIndex = 18;
            // 
            // label_BucketSpeedWithLoad
            // 
            this.label_BucketSpeedWithLoad.AutoSize = true;
            this.label_BucketSpeedWithLoad.Location = new System.Drawing.Point(698, 75);
            this.label_BucketSpeedWithLoad.Name = "label_BucketSpeedWithLoad";
            this.label_BucketSpeedWithLoad.Size = new System.Drawing.Size(253, 21);
            this.label_BucketSpeedWithLoad.TabIndex = 17;
            this.label_BucketSpeedWithLoad.Text = "Скорость ковша с грузом, м/с";
            // 
            // textBox_BucketSpeedWithoutLoad
            // 
            this.textBox_BucketSpeedWithoutLoad.Location = new System.Drawing.Point(279, 110);
            this.textBox_BucketSpeedWithoutLoad.Name = "textBox_BucketSpeedWithoutLoad";
            this.textBox_BucketSpeedWithoutLoad.ReadOnly = true;
            this.textBox_BucketSpeedWithoutLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketSpeedWithoutLoad.TabIndex = 16;
            // 
            // label_BucketSpeedWithoutLoad
            // 
            this.label_BucketSpeedWithoutLoad.AutoSize = true;
            this.label_BucketSpeedWithoutLoad.Location = new System.Drawing.Point(17, 113);
            this.label_BucketSpeedWithoutLoad.Name = "label_BucketSpeedWithoutLoad";
            this.label_BucketSpeedWithoutLoad.Size = new System.Drawing.Size(256, 21);
            this.label_BucketSpeedWithoutLoad.TabIndex = 15;
            this.label_BucketSpeedWithoutLoad.Text = "Скорость ковша без груза, м/с";
            // 
            // textBox_BucketTipTime
            // 
            this.textBox_BucketTipTime.Location = new System.Drawing.Point(607, 72);
            this.textBox_BucketTipTime.Name = "textBox_BucketTipTime";
            this.textBox_BucketTipTime.ReadOnly = true;
            this.textBox_BucketTipTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketTipTime.TabIndex = 14;
            // 
            // label_BucketTipTime
            // 
            this.label_BucketTipTime.AutoSize = true;
            this.label_BucketTipTime.Location = new System.Drawing.Point(328, 75);
            this.label_BucketTipTime.Name = "label_BucketTipTime";
            this.label_BucketTipTime.Size = new System.Drawing.Size(273, 21);
            this.label_BucketTipTime.TabIndex = 13;
            this.label_BucketTipTime.Text = "Время запрокидывания ковша, с";
            // 
            // textBox_LoadedSpeed
            // 
            this.textBox_LoadedSpeed.Location = new System.Drawing.Point(222, 72);
            this.textBox_LoadedSpeed.Name = "textBox_LoadedSpeed";
            this.textBox_LoadedSpeed.ReadOnly = true;
            this.textBox_LoadedSpeed.Size = new System.Drawing.Size(100, 29);
            this.textBox_LoadedSpeed.TabIndex = 12;
            // 
            // label_LoadedSpeed
            // 
            this.label_LoadedSpeed.AutoSize = true;
            this.label_LoadedSpeed.Location = new System.Drawing.Point(17, 75);
            this.label_LoadedSpeed.Name = "label_LoadedSpeed";
            this.label_LoadedSpeed.Size = new System.Drawing.Size(199, 21);
            this.label_LoadedSpeed.TabIndex = 11;
            this.label_LoadedSpeed.Text = "Скорость с грузом, м/с";
            // 
            // textBox_SpeedWithoutLoad
            // 
            this.textBox_SpeedWithoutLoad.Location = new System.Drawing.Point(1087, 29);
            this.textBox_SpeedWithoutLoad.Name = "textBox_SpeedWithoutLoad";
            this.textBox_SpeedWithoutLoad.ReadOnly = true;
            this.textBox_SpeedWithoutLoad.Size = new System.Drawing.Size(97, 29);
            this.textBox_SpeedWithoutLoad.TabIndex = 10;
            // 
            // label_SpeedWithoutLoad
            // 
            this.label_SpeedWithoutLoad.AutoSize = true;
            this.label_SpeedWithoutLoad.Location = new System.Drawing.Point(879, 32);
            this.label_SpeedWithoutLoad.Name = "label_SpeedWithoutLoad";
            this.label_SpeedWithoutLoad.Size = new System.Drawing.Size(202, 21);
            this.label_SpeedWithoutLoad.TabIndex = 9;
            this.label_SpeedWithoutLoad.Text = "Скорость без груза, м/с";
            // 
            // textBox_BucketVolume
            // 
            this.textBox_BucketVolume.Location = new System.Drawing.Point(788, 29);
            this.textBox_BucketVolume.Name = "textBox_BucketVolume";
            this.textBox_BucketVolume.ReadOnly = true;
            this.textBox_BucketVolume.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketVolume.TabIndex = 8;
            // 
            // label_BucketVolume
            // 
            this.label_BucketVolume.AutoSize = true;
            this.label_BucketVolume.Location = new System.Drawing.Point(625, 32);
            this.label_BucketVolume.Name = "label_BucketVolume";
            this.label_BucketVolume.Size = new System.Drawing.Size(157, 21);
            this.label_BucketVolume.TabIndex = 7;
            this.label_BucketVolume.Text = "Объем ковша, м^3";
            // 
            // textBox_LoaderCapacity
            // 
            this.textBox_LoaderCapacity.Location = new System.Drawing.Point(514, 29);
            this.textBox_LoaderCapacity.Name = "textBox_LoaderCapacity";
            this.textBox_LoaderCapacity.ReadOnly = true;
            this.textBox_LoaderCapacity.Size = new System.Drawing.Size(105, 29);
            this.textBox_LoaderCapacity.TabIndex = 6;
            // 
            // label_LoaderCapacity
            // 
            this.label_LoaderCapacity.AutoSize = true;
            this.label_LoaderCapacity.Location = new System.Drawing.Point(328, 32);
            this.label_LoaderCapacity.Name = "label_LoaderCapacity";
            this.label_LoaderCapacity.Size = new System.Drawing.Size(180, 21);
            this.label_LoaderCapacity.TabIndex = 3;
            this.label_LoaderCapacity.Text = "Грузоподъемность, т";
            // 
            // comboBox_LoaderBrand
            // 
            this.comboBox_LoaderBrand.FormattingEnabled = true;
            this.comboBox_LoaderBrand.Items.AddRange(new object[] {
            "ТО-28",
            "ТО-8",
            "ТО-21"});
            this.comboBox_LoaderBrand.Location = new System.Drawing.Point(181, 29);
            this.comboBox_LoaderBrand.Name = "comboBox_LoaderBrand";
            this.comboBox_LoaderBrand.Size = new System.Drawing.Size(141, 29);
            this.comboBox_LoaderBrand.TabIndex = 2;
            this.comboBox_LoaderBrand.SelectedIndexChanged += new System.EventHandler(this.comboBox_LoaderBrand_SelectedIndexChanged);
            // 
            // label_LoaderBrand
            // 
            this.label_LoaderBrand.AutoSize = true;
            this.label_LoaderBrand.Location = new System.Drawing.Point(17, 32);
            this.label_LoaderBrand.Name = "label_LoaderBrand";
            this.label_LoaderBrand.Size = new System.Drawing.Size(158, 21);
            this.label_LoaderBrand.TabIndex = 1;
            this.label_LoaderBrand.Text = "Марка погрузчика";
            // 
            // groupBox_Report
            // 
            this.groupBox_Report.Controls.Add(this.textBox_ReportName);
            this.groupBox_Report.Controls.Add(this.label_ReportName);
            this.groupBox_Report.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Report.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Report.Location = new System.Drawing.Point(0, 236);
            this.groupBox_Report.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Report.Name = "groupBox_Report";
            this.groupBox_Report.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_Report.Size = new System.Drawing.Size(1332, 79);
            this.groupBox_Report.TabIndex = 4;
            this.groupBox_Report.TabStop = false;
            this.groupBox_Report.Text = "Введите данные отчета";
            // 
            // textBox_ReportName
            // 
            this.textBox_ReportName.Location = new System.Drawing.Point(112, 29);
            this.textBox_ReportName.Name = "textBox_ReportName";
            this.textBox_ReportName.Size = new System.Drawing.Size(257, 29);
            this.textBox_ReportName.TabIndex = 21;
            // 
            // label_ReportName
            // 
            this.label_ReportName.AutoSize = true;
            this.label_ReportName.Location = new System.Drawing.Point(22, 32);
            this.label_ReportName.Name = "label_ReportName";
            this.label_ReportName.Size = new System.Drawing.Size(84, 21);
            this.label_ReportName.TabIndex = 20;
            this.label_ReportName.Text = "Название";
            // 
            // groupBox_Distance
            // 
            this.groupBox_Distance.Controls.Add(this.textBox_L5);
            this.groupBox_Distance.Controls.Add(this.label_L5);
            this.groupBox_Distance.Controls.Add(this.textBox_L4);
            this.groupBox_Distance.Controls.Add(this.label_L4);
            this.groupBox_Distance.Controls.Add(this.textBox_L3);
            this.groupBox_Distance.Controls.Add(this.label_L3);
            this.groupBox_Distance.Controls.Add(this.textBox_L2);
            this.groupBox_Distance.Controls.Add(this.label_L2);
            this.groupBox_Distance.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Distance.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Distance.Location = new System.Drawing.Point(0, 315);
            this.groupBox_Distance.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Distance.Name = "groupBox_Distance";
            this.groupBox_Distance.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_Distance.Size = new System.Drawing.Size(1332, 118);
            this.groupBox_Distance.TabIndex = 5;
            this.groupBox_Distance.TabStop = false;
            this.groupBox_Distance.Text = "Введите данные расстояний";
            // 
            // textBox_L5
            // 
            this.textBox_L5.Location = new System.Drawing.Point(995, 70);
            this.textBox_L5.Name = "textBox_L5";
            this.textBox_L5.Size = new System.Drawing.Size(189, 29);
            this.textBox_L5.TabIndex = 27;
            // 
            // label_L5
            // 
            this.label_L5.AutoSize = true;
            this.label_L5.Location = new System.Drawing.Point(493, 73);
            this.label_L5.Name = "label_L5";
            this.label_L5.Size = new System.Drawing.Size(496, 21);
            this.label_L5.TabIndex = 26;
            this.label_L5.Text = "Перемещение погрузчика при движении к штабелю груза, м";
            // 
            // textBox_L4
            // 
            this.textBox_L4.Location = new System.Drawing.Point(347, 70);
            this.textBox_L4.Name = "textBox_L4";
            this.textBox_L4.Size = new System.Drawing.Size(140, 29);
            this.textBox_L4.TabIndex = 25;
            // 
            // label_L4
            // 
            this.label_L4.AutoSize = true;
            this.label_L4.Location = new System.Drawing.Point(22, 73);
            this.label_L4.Name = "label_L4";
            this.label_L4.Size = new System.Drawing.Size(319, 21);
            this.label_L4.TabIndex = 24;
            this.label_L4.Text = "Перемещение погрузчика от вагона, м";
            // 
            // textBox_L3
            // 
            this.textBox_L3.Location = new System.Drawing.Point(1053, 29);
            this.textBox_L3.Name = "textBox_L3";
            this.textBox_L3.Size = new System.Drawing.Size(131, 29);
            this.textBox_L3.TabIndex = 23;
            // 
            // label_L3
            // 
            this.label_L3.AutoSize = true;
            this.label_L3.Location = new System.Drawing.Point(625, 32);
            this.label_L3.Name = "label_L3";
            this.label_L3.Size = new System.Drawing.Size(422, 21);
            this.label_L3.TabIndex = 22;
            this.label_L3.Text = "Перемещение погрузчика при подъезде к вагону, м";
            // 
            // textBox_L2
            // 
            this.textBox_L2.Location = new System.Drawing.Point(510, 29);
            this.textBox_L2.Name = "textBox_L2";
            this.textBox_L2.Size = new System.Drawing.Size(109, 29);
            this.textBox_L2.TabIndex = 21;
            // 
            // label_L2
            // 
            this.label_L2.AutoSize = true;
            this.label_L2.Location = new System.Drawing.Point(22, 32);
            this.label_L2.Name = "label_L2";
            this.label_L2.Size = new System.Drawing.Size(482, 21);
            this.label_L2.TabIndex = 20;
            this.label_L2.Text = "Перемещение погрузчика при отъезде от штабеля груза, м";
            // 
            // groupBox_Result
            // 
            this.groupBox_Result.Controls.Add(this.textBox_ResSideHeight);
            this.groupBox_Result.Controls.Add(this.label_ResSideHeight);
            this.groupBox_Result.Controls.Add(this.textBox_TrainServiceTime);
            this.groupBox_Result.Controls.Add(this.label_TrainServiceTime);
            this.groupBox_Result.Controls.Add(this.textBox_WagonServiceTime);
            this.groupBox_Result.Controls.Add(this.label_WagonServiceTime);
            this.groupBox_Result.Controls.Add(this.textBox_LoaderPerformance);
            this.groupBox_Result.Controls.Add(this.label_LoaderPerformance);
            this.groupBox_Result.Controls.Add(this.textBox_TechnicalLoaderPerformance);
            this.groupBox_Result.Controls.Add(this.label_TechnicalLoaderPerformance);
            this.groupBox_Result.Controls.Add(this.textBox_LoaderCycle);
            this.groupBox_Result.Controls.Add(this.label_LoaderCycle);
            this.groupBox_Result.Controls.Add(this.textBox_ResL5);
            this.groupBox_Result.Controls.Add(this.label_ResL5);
            this.groupBox_Result.Controls.Add(this.textBox_ResL4);
            this.groupBox_Result.Controls.Add(this.label_ResL4);
            this.groupBox_Result.Controls.Add(this.textBox_ResL3);
            this.groupBox_Result.Controls.Add(this.label_ResL3);
            this.groupBox_Result.Controls.Add(this.textBox_ResL2);
            this.groupBox_Result.Controls.Add(this.label_ResL2);
            this.groupBox_Result.Controls.Add(this.textBox_ResAverageDumpingTimeFromTheBucket);
            this.groupBox_Result.Controls.Add(this.label_ResAverageDumpingTimeFromTheBucket);
            this.groupBox_Result.Controls.Add(this.textBox_ResAverageBucketFillingTime);
            this.groupBox_Result.Controls.Add(this.label_ResAverageBucketFillingTime);
            this.groupBox_Result.Controls.Add(this.textBox_ResBucketSpeedWithoutLoad);
            this.groupBox_Result.Controls.Add(this.label_ResBucketSpeedWithoutLoad);
            this.groupBox_Result.Controls.Add(this.textBox_ResBucketSpeedWithLoad);
            this.groupBox_Result.Controls.Add(this.label_ResBucketSpeedWithLoad);
            this.groupBox_Result.Controls.Add(this.textBox_ResBucketTipTime);
            this.groupBox_Result.Controls.Add(this.label_ResBucketTipTime);
            this.groupBox_Result.Controls.Add(this.textBox_ResLoadedSpeed);
            this.groupBox_Result.Controls.Add(this.label_ResLoadedSpeed);
            this.groupBox_Result.Controls.Add(this.textBox_ResSpeedWithoutLoad);
            this.groupBox_Result.Controls.Add(this.label_ResSpeedWithoutLoad);
            this.groupBox_Result.Controls.Add(this.textBox_ResBucketVolume);
            this.groupBox_Result.Controls.Add(this.label_ResBucketVolume);
            this.groupBox_Result.Controls.Add(this.textBox_ResLoaderCapacity);
            this.groupBox_Result.Controls.Add(this.label_ResLoaderCapacity);
            this.groupBox_Result.Controls.Add(this.textBox_ResLoaderBrand);
            this.groupBox_Result.Controls.Add(this.label_ResLoaderBrand);
            this.groupBox_Result.Controls.Add(this.textBox_ResWagonCapacity);
            this.groupBox_Result.Controls.Add(this.label_ResNumberOfWagons);
            this.groupBox_Result.Controls.Add(this.textBox_ResNumberOfWagons);
            this.groupBox_Result.Controls.Add(this.label_ResWagonCapacity);
            this.groupBox_Result.Controls.Add(this.textBox_ResWagonModel);
            this.groupBox_Result.Controls.Add(this.label_ResWagonModel);
            this.groupBox_Result.Controls.Add(this.textBox_ResReportName);
            this.groupBox_Result.Controls.Add(this.label_ResReportName);
            this.groupBox_Result.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Result.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Result.Location = new System.Drawing.Point(0, 433);
            this.groupBox_Result.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Result.Name = "groupBox_Result";
            this.groupBox_Result.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_Result.Size = new System.Drawing.Size(1332, 370);
            this.groupBox_Result.TabIndex = 6;
            this.groupBox_Result.TabStop = false;
            this.groupBox_Result.Text = "Результаты расчета";
            this.groupBox_Result.Visible = false;
            // 
            // textBox_ResSideHeight
            // 
            this.textBox_ResSideHeight.Location = new System.Drawing.Point(1040, 324);
            this.textBox_ResSideHeight.Name = "textBox_ResSideHeight";
            this.textBox_ResSideHeight.ReadOnly = true;
            this.textBox_ResSideHeight.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResSideHeight.TabIndex = 67;
            // 
            // label_ResSideHeight
            // 
            this.label_ResSideHeight.AutoSize = true;
            this.label_ResSideHeight.Location = new System.Drawing.Point(833, 327);
            this.label_ResSideHeight.Name = "label_ResSideHeight";
            this.label_ResSideHeight.Size = new System.Drawing.Size(201, 21);
            this.label_ResSideHeight.TabIndex = 66;
            this.label_ResSideHeight.Text = "Высота борта вагона, м";
            // 
            // textBox_TrainServiceTime
            // 
            this.textBox_TrainServiceTime.Location = new System.Drawing.Point(728, 324);
            this.textBox_TrainServiceTime.Name = "textBox_TrainServiceTime";
            this.textBox_TrainServiceTime.ReadOnly = true;
            this.textBox_TrainServiceTime.Size = new System.Drawing.Size(99, 29);
            this.textBox_TrainServiceTime.TabIndex = 65;
            // 
            // label_TrainServiceTime
            // 
            this.label_TrainServiceTime.AutoSize = true;
            this.label_TrainServiceTime.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_TrainServiceTime.Location = new System.Drawing.Point(436, 326);
            this.label_TrainServiceTime.Name = "label_TrainServiceTime";
            this.label_TrainServiceTime.Size = new System.Drawing.Size(286, 22);
            this.label_TrainServiceTime.TabIndex = 64;
            this.label_TrainServiceTime.Text = "Время обслуживания состава, с";
            // 
            // textBox_WagonServiceTime
            // 
            this.textBox_WagonServiceTime.Location = new System.Drawing.Point(307, 324);
            this.textBox_WagonServiceTime.Name = "textBox_WagonServiceTime";
            this.textBox_WagonServiceTime.ReadOnly = true;
            this.textBox_WagonServiceTime.Size = new System.Drawing.Size(123, 29);
            this.textBox_WagonServiceTime.TabIndex = 63;
            // 
            // label_WagonServiceTime
            // 
            this.label_WagonServiceTime.AutoSize = true;
            this.label_WagonServiceTime.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_WagonServiceTime.Location = new System.Drawing.Point(22, 326);
            this.label_WagonServiceTime.Name = "label_WagonServiceTime";
            this.label_WagonServiceTime.Size = new System.Drawing.Size(279, 22);
            this.label_WagonServiceTime.TabIndex = 62;
            this.label_WagonServiceTime.Text = "Время обслуживания вагона, с";
            // 
            // textBox_LoaderPerformance
            // 
            this.textBox_LoaderPerformance.Location = new System.Drawing.Point(1162, 277);
            this.textBox_LoaderPerformance.Name = "textBox_LoaderPerformance";
            this.textBox_LoaderPerformance.ReadOnly = true;
            this.textBox_LoaderPerformance.Size = new System.Drawing.Size(123, 29);
            this.textBox_LoaderPerformance.TabIndex = 61;
            // 
            // label_LoaderPerformance
            // 
            this.label_LoaderPerformance.AutoSize = true;
            this.label_LoaderPerformance.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_LoaderPerformance.Location = new System.Drawing.Point(740, 279);
            this.label_LoaderPerformance.Name = "label_LoaderPerformance";
            this.label_LoaderPerformance.Size = new System.Drawing.Size(416, 22);
            this.label_LoaderPerformance.TabIndex = 60;
            this.label_LoaderPerformance.Text = "Эксплуатационная произв-ть погрузчика, м^3";
            // 
            // textBox_TechnicalLoaderPerformance
            // 
            this.textBox_TechnicalLoaderPerformance.Location = new System.Drawing.Point(658, 277);
            this.textBox_TechnicalLoaderPerformance.Name = "textBox_TechnicalLoaderPerformance";
            this.textBox_TechnicalLoaderPerformance.ReadOnly = true;
            this.textBox_TechnicalLoaderPerformance.Size = new System.Drawing.Size(76, 29);
            this.textBox_TechnicalLoaderPerformance.TabIndex = 59;
            // 
            // label_TechnicalLoaderPerformance
            // 
            this.label_TechnicalLoaderPerformance.AutoSize = true;
            this.label_TechnicalLoaderPerformance.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_TechnicalLoaderPerformance.Location = new System.Drawing.Point(291, 279);
            this.label_TechnicalLoaderPerformance.Name = "label_TechnicalLoaderPerformance";
            this.label_TechnicalLoaderPerformance.Size = new System.Drawing.Size(361, 22);
            this.label_TechnicalLoaderPerformance.TabIndex = 58;
            this.label_TechnicalLoaderPerformance.Text = "Техническая произв-ть погрузчика, м^3";
            // 
            // textBox_LoaderCycle
            // 
            this.textBox_LoaderCycle.Location = new System.Drawing.Point(209, 277);
            this.textBox_LoaderCycle.Name = "textBox_LoaderCycle";
            this.textBox_LoaderCycle.ReadOnly = true;
            this.textBox_LoaderCycle.Size = new System.Drawing.Size(76, 29);
            this.textBox_LoaderCycle.TabIndex = 57;
            // 
            // label_LoaderCycle
            // 
            this.label_LoaderCycle.AutoSize = true;
            this.label_LoaderCycle.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_LoaderCycle.Location = new System.Drawing.Point(22, 279);
            this.label_LoaderCycle.Name = "label_LoaderCycle";
            this.label_LoaderCycle.Size = new System.Drawing.Size(181, 22);
            this.label_LoaderCycle.TabIndex = 56;
            this.label_LoaderCycle.Text = "Цикл погрузчика, с";
            // 
            // textBox_ResL5
            // 
            this.textBox_ResL5.Location = new System.Drawing.Point(931, 231);
            this.textBox_ResL5.Name = "textBox_ResL5";
            this.textBox_ResL5.ReadOnly = true;
            this.textBox_ResL5.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResL5.TabIndex = 55;
            // 
            // label_ResL5
            // 
            this.label_ResL5.AutoSize = true;
            this.label_ResL5.Location = new System.Drawing.Point(429, 234);
            this.label_ResL5.Name = "label_ResL5";
            this.label_ResL5.Size = new System.Drawing.Size(496, 21);
            this.label_ResL5.TabIndex = 54;
            this.label_ResL5.Text = "Перемещение погрузчика при движении к штабелю груза, м";
            // 
            // textBox_ResL4
            // 
            this.textBox_ResL4.Location = new System.Drawing.Point(347, 231);
            this.textBox_ResL4.Name = "textBox_ResL4";
            this.textBox_ResL4.ReadOnly = true;
            this.textBox_ResL4.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResL4.TabIndex = 53;
            // 
            // label_ResL4
            // 
            this.label_ResL4.AutoSize = true;
            this.label_ResL4.Location = new System.Drawing.Point(22, 234);
            this.label_ResL4.Name = "label_ResL4";
            this.label_ResL4.Size = new System.Drawing.Size(319, 21);
            this.label_ResL4.TabIndex = 52;
            this.label_ResL4.Text = "Перемещение погрузчика от вагона, м";
            // 
            // textBox_ResL3
            // 
            this.textBox_ResL3.Location = new System.Drawing.Point(1020, 192);
            this.textBox_ResL3.Name = "textBox_ResL3";
            this.textBox_ResL3.ReadOnly = true;
            this.textBox_ResL3.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResL3.TabIndex = 51;
            // 
            // label_ResL3
            // 
            this.label_ResL3.AutoSize = true;
            this.label_ResL3.Location = new System.Drawing.Point(592, 195);
            this.label_ResL3.Name = "label_ResL3";
            this.label_ResL3.Size = new System.Drawing.Size(422, 21);
            this.label_ResL3.TabIndex = 50;
            this.label_ResL3.Text = "Перемещение погрузчика при подъезде к вагону, м";
            // 
            // textBox_ResL2
            // 
            this.textBox_ResL2.Location = new System.Drawing.Point(510, 192);
            this.textBox_ResL2.Name = "textBox_ResL2";
            this.textBox_ResL2.ReadOnly = true;
            this.textBox_ResL2.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResL2.TabIndex = 49;
            // 
            // label_ResL2
            // 
            this.label_ResL2.AutoSize = true;
            this.label_ResL2.Location = new System.Drawing.Point(22, 195);
            this.label_ResL2.Name = "label_ResL2";
            this.label_ResL2.Size = new System.Drawing.Size(482, 21);
            this.label_ResL2.TabIndex = 48;
            this.label_ResL2.Text = "Перемещение погрузчика при отъезде от штабеля груза, м";
            // 
            // textBox_ResAverageDumpingTimeFromTheBucket
            // 
            this.textBox_ResAverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(795, 153);
            this.textBox_ResAverageDumpingTimeFromTheBucket.Name = "textBox_ResAverageDumpingTimeFromTheBucket";
            this.textBox_ResAverageDumpingTimeFromTheBucket.ReadOnly = true;
            this.textBox_ResAverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResAverageDumpingTimeFromTheBucket.TabIndex = 47;
            // 
            // label_ResAverageDumpingTimeFromTheBucket
            // 
            this.label_ResAverageDumpingTimeFromTheBucket.AutoSize = true;
            this.label_ResAverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(419, 156);
            this.label_ResAverageDumpingTimeFromTheBucket.Name = "label_ResAverageDumpingTimeFromTheBucket";
            this.label_ResAverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(370, 21);
            this.label_ResAverageDumpingTimeFromTheBucket.TabIndex = 46;
            this.label_ResAverageDumpingTimeFromTheBucket.Text = "Среднее время высыпания груза из ковша, с";
            // 
            // textBox_ResAverageBucketFillingTime
            // 
            this.textBox_ResAverageBucketFillingTime.Location = new System.Drawing.Point(328, 153);
            this.textBox_ResAverageBucketFillingTime.Name = "textBox_ResAverageBucketFillingTime";
            this.textBox_ResAverageBucketFillingTime.ReadOnly = true;
            this.textBox_ResAverageBucketFillingTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResAverageBucketFillingTime.TabIndex = 45;
            // 
            // label_ResAverageBucketFillingTime
            // 
            this.label_ResAverageBucketFillingTime.AutoSize = true;
            this.label_ResAverageBucketFillingTime.Location = new System.Drawing.Point(22, 156);
            this.label_ResAverageBucketFillingTime.Name = "label_ResAverageBucketFillingTime";
            this.label_ResAverageBucketFillingTime.Size = new System.Drawing.Size(300, 21);
            this.label_ResAverageBucketFillingTime.TabIndex = 44;
            this.label_ResAverageBucketFillingTime.Text = "Среднее время заполнения ковша, с";
            // 
            // textBox_ResBucketSpeedWithoutLoad
            // 
            this.textBox_ResBucketSpeedWithoutLoad.Location = new System.Drawing.Point(1300, 115);
            this.textBox_ResBucketSpeedWithoutLoad.Name = "textBox_ResBucketSpeedWithoutLoad";
            this.textBox_ResBucketSpeedWithoutLoad.ReadOnly = true;
            this.textBox_ResBucketSpeedWithoutLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResBucketSpeedWithoutLoad.TabIndex = 43;
            // 
            // label_ResBucketSpeedWithoutLoad
            // 
            this.label_ResBucketSpeedWithoutLoad.AutoSize = true;
            this.label_ResBucketSpeedWithoutLoad.Location = new System.Drawing.Point(1038, 118);
            this.label_ResBucketSpeedWithoutLoad.Name = "label_ResBucketSpeedWithoutLoad";
            this.label_ResBucketSpeedWithoutLoad.Size = new System.Drawing.Size(256, 21);
            this.label_ResBucketSpeedWithoutLoad.TabIndex = 42;
            this.label_ResBucketSpeedWithoutLoad.Text = "Скорость ковша без груза, м/с";
            // 
            // textBox_ResBucketSpeedWithLoad
            // 
            this.textBox_ResBucketSpeedWithLoad.Location = new System.Drawing.Point(947, 115);
            this.textBox_ResBucketSpeedWithLoad.Name = "textBox_ResBucketSpeedWithLoad";
            this.textBox_ResBucketSpeedWithLoad.ReadOnly = true;
            this.textBox_ResBucketSpeedWithLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResBucketSpeedWithLoad.TabIndex = 41;
            // 
            // label_ResBucketSpeedWithLoad
            // 
            this.label_ResBucketSpeedWithLoad.AutoSize = true;
            this.label_ResBucketSpeedWithLoad.Location = new System.Drawing.Point(688, 118);
            this.label_ResBucketSpeedWithLoad.Name = "label_ResBucketSpeedWithLoad";
            this.label_ResBucketSpeedWithLoad.Size = new System.Drawing.Size(253, 21);
            this.label_ResBucketSpeedWithLoad.TabIndex = 40;
            this.label_ResBucketSpeedWithLoad.Text = "Скорость ковша с грузом, м/с";
            // 
            // textBox_ResBucketTipTime
            // 
            this.textBox_ResBucketTipTime.Location = new System.Drawing.Point(597, 115);
            this.textBox_ResBucketTipTime.Name = "textBox_ResBucketTipTime";
            this.textBox_ResBucketTipTime.ReadOnly = true;
            this.textBox_ResBucketTipTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResBucketTipTime.TabIndex = 39;
            // 
            // label_ResBucketTipTime
            // 
            this.label_ResBucketTipTime.AutoSize = true;
            this.label_ResBucketTipTime.Location = new System.Drawing.Point(318, 118);
            this.label_ResBucketTipTime.Name = "label_ResBucketTipTime";
            this.label_ResBucketTipTime.Size = new System.Drawing.Size(273, 21);
            this.label_ResBucketTipTime.TabIndex = 38;
            this.label_ResBucketTipTime.Text = "Время запрокидывания ковша, с";
            // 
            // textBox_ResLoadedSpeed
            // 
            this.textBox_ResLoadedSpeed.Location = new System.Drawing.Point(227, 115);
            this.textBox_ResLoadedSpeed.Name = "textBox_ResLoadedSpeed";
            this.textBox_ResLoadedSpeed.ReadOnly = true;
            this.textBox_ResLoadedSpeed.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResLoadedSpeed.TabIndex = 37;
            // 
            // label_ResLoadedSpeed
            // 
            this.label_ResLoadedSpeed.AutoSize = true;
            this.label_ResLoadedSpeed.Location = new System.Drawing.Point(22, 118);
            this.label_ResLoadedSpeed.Name = "label_ResLoadedSpeed";
            this.label_ResLoadedSpeed.Size = new System.Drawing.Size(199, 21);
            this.label_ResLoadedSpeed.TabIndex = 36;
            this.label_ResLoadedSpeed.Text = "Скорость с грузом, м/с";
            // 
            // textBox_ResSpeedWithoutLoad
            // 
            this.textBox_ResSpeedWithoutLoad.Location = new System.Drawing.Point(1194, 72);
            this.textBox_ResSpeedWithoutLoad.Name = "textBox_ResSpeedWithoutLoad";
            this.textBox_ResSpeedWithoutLoad.ReadOnly = true;
            this.textBox_ResSpeedWithoutLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResSpeedWithoutLoad.TabIndex = 35;
            // 
            // label_ResSpeedWithoutLoad
            // 
            this.label_ResSpeedWithoutLoad.AutoSize = true;
            this.label_ResSpeedWithoutLoad.Location = new System.Drawing.Point(986, 75);
            this.label_ResSpeedWithoutLoad.Name = "label_ResSpeedWithoutLoad";
            this.label_ResSpeedWithoutLoad.Size = new System.Drawing.Size(202, 21);
            this.label_ResSpeedWithoutLoad.TabIndex = 34;
            this.label_ResSpeedWithoutLoad.Text = "Скорость без груза, м/с";
            // 
            // textBox_ResBucketVolume
            // 
            this.textBox_ResBucketVolume.Location = new System.Drawing.Point(895, 72);
            this.textBox_ResBucketVolume.Name = "textBox_ResBucketVolume";
            this.textBox_ResBucketVolume.ReadOnly = true;
            this.textBox_ResBucketVolume.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResBucketVolume.TabIndex = 33;
            // 
            // label_ResBucketVolume
            // 
            this.label_ResBucketVolume.AutoSize = true;
            this.label_ResBucketVolume.Location = new System.Drawing.Point(732, 75);
            this.label_ResBucketVolume.Name = "label_ResBucketVolume";
            this.label_ResBucketVolume.Size = new System.Drawing.Size(157, 21);
            this.label_ResBucketVolume.TabIndex = 32;
            this.label_ResBucketVolume.Text = "Объем ковша, м^3";
            // 
            // textBox_ResLoaderCapacity
            // 
            this.textBox_ResLoaderCapacity.Location = new System.Drawing.Point(641, 72);
            this.textBox_ResLoaderCapacity.Name = "textBox_ResLoaderCapacity";
            this.textBox_ResLoaderCapacity.ReadOnly = true;
            this.textBox_ResLoaderCapacity.Size = new System.Drawing.Size(85, 29);
            this.textBox_ResLoaderCapacity.TabIndex = 31;
            // 
            // label_ResLoaderCapacity
            // 
            this.label_ResLoaderCapacity.AutoSize = true;
            this.label_ResLoaderCapacity.Location = new System.Drawing.Point(358, 75);
            this.label_ResLoaderCapacity.Name = "label_ResLoaderCapacity";
            this.label_ResLoaderCapacity.Size = new System.Drawing.Size(277, 21);
            this.label_ResLoaderCapacity.TabIndex = 30;
            this.label_ResLoaderCapacity.Text = "Грузоподъемность погрузчика, т";
            // 
            // textBox_ResLoaderBrand
            // 
            this.textBox_ResLoaderBrand.Location = new System.Drawing.Point(186, 72);
            this.textBox_ResLoaderBrand.Name = "textBox_ResLoaderBrand";
            this.textBox_ResLoaderBrand.ReadOnly = true;
            this.textBox_ResLoaderBrand.Size = new System.Drawing.Size(166, 29);
            this.textBox_ResLoaderBrand.TabIndex = 29;
            // 
            // label_ResLoaderBrand
            // 
            this.label_ResLoaderBrand.AutoSize = true;
            this.label_ResLoaderBrand.Location = new System.Drawing.Point(22, 75);
            this.label_ResLoaderBrand.Name = "label_ResLoaderBrand";
            this.label_ResLoaderBrand.Size = new System.Drawing.Size(158, 21);
            this.label_ResLoaderBrand.TabIndex = 28;
            this.label_ResLoaderBrand.Text = "Марка погрузчика";
            // 
            // textBox_ResWagonCapacity
            // 
            this.textBox_ResWagonCapacity.Location = new System.Drawing.Point(927, 29);
            this.textBox_ResWagonCapacity.Name = "textBox_ResWagonCapacity";
            this.textBox_ResWagonCapacity.ReadOnly = true;
            this.textBox_ResWagonCapacity.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResWagonCapacity.TabIndex = 27;
            // 
            // label_ResNumberOfWagons
            // 
            this.label_ResNumberOfWagons.AutoSize = true;
            this.label_ResNumberOfWagons.Location = new System.Drawing.Point(1009, 32);
            this.label_ResNumberOfWagons.Name = "label_ResNumberOfWagons";
            this.label_ResNumberOfWagons.Size = new System.Drawing.Size(206, 21);
            this.label_ResNumberOfWagons.TabIndex = 26;
            this.label_ResNumberOfWagons.Text = "Количество вагонов, шт";
            // 
            // textBox_ResNumberOfWagons
            // 
            this.textBox_ResNumberOfWagons.Location = new System.Drawing.Point(1221, 29);
            this.textBox_ResNumberOfWagons.Name = "textBox_ResNumberOfWagons";
            this.textBox_ResNumberOfWagons.ReadOnly = true;
            this.textBox_ResNumberOfWagons.Size = new System.Drawing.Size(76, 29);
            this.textBox_ResNumberOfWagons.TabIndex = 25;
            // 
            // label_ResWagonCapacity
            // 
            this.label_ResWagonCapacity.AutoSize = true;
            this.label_ResWagonCapacity.Location = new System.Drawing.Point(683, 32);
            this.label_ResWagonCapacity.Name = "label_ResWagonCapacity";
            this.label_ResWagonCapacity.Size = new System.Drawing.Size(238, 21);
            this.label_ResWagonCapacity.TabIndex = 24;
            this.label_ResWagonCapacity.Text = "Грузоподъемность вагона, т";
            // 
            // textBox_ResWagonModel
            // 
            this.textBox_ResWagonModel.Location = new System.Drawing.Point(493, 29);
            this.textBox_ResWagonModel.Name = "textBox_ResWagonModel";
            this.textBox_ResWagonModel.ReadOnly = true;
            this.textBox_ResWagonModel.Size = new System.Drawing.Size(184, 29);
            this.textBox_ResWagonModel.TabIndex = 23;
            // 
            // label_ResWagonModel
            // 
            this.label_ResWagonModel.AutoSize = true;
            this.label_ResWagonModel.Location = new System.Drawing.Point(358, 32);
            this.label_ResWagonModel.Name = "label_ResWagonModel";
            this.label_ResWagonModel.Size = new System.Drawing.Size(129, 21);
            this.label_ResWagonModel.TabIndex = 22;
            this.label_ResWagonModel.Text = "Модель вагона";
            // 
            // textBox_ResReportName
            // 
            this.textBox_ResReportName.Location = new System.Drawing.Point(169, 29);
            this.textBox_ResReportName.Name = "textBox_ResReportName";
            this.textBox_ResReportName.ReadOnly = true;
            this.textBox_ResReportName.Size = new System.Drawing.Size(183, 29);
            this.textBox_ResReportName.TabIndex = 21;
            // 
            // label_ResReportName
            // 
            this.label_ResReportName.AutoSize = true;
            this.label_ResReportName.Location = new System.Drawing.Point(22, 32);
            this.label_ResReportName.Name = "label_ResReportName";
            this.label_ResReportName.Size = new System.Drawing.Size(141, 21);
            this.label_ResReportName.TabIndex = 20;
            this.label_ResReportName.Text = "Название отчета";
            // 
            // FormCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1582, 839);
            this.Controls.Add(this.groupBox_Result);
            this.Controls.Add(this.groupBox_Distance);
            this.Controls.Add(this.groupBox_Report);
            this.Controls.Add(this.groupBox_Loader);
            this.Controls.Add(this.groupBox_RollingStock);
            this.Controls.Add(this.groupBox_Buttons);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormCalc";
            this.Text = "Расчет производительности и времени";
            this.Load += new System.EventHandler(this.FormCalc_Load);
            this.groupBox_Buttons.ResumeLayout(false);
            this.groupBox_Buttons.PerformLayout();
            this.groupBox_RollingStock.ResumeLayout(false);
            this.groupBox_RollingStock.PerformLayout();
            this.groupBox_Loader.ResumeLayout(false);
            this.groupBox_Loader.PerformLayout();
            this.groupBox_Report.ResumeLayout(false);
            this.groupBox_Report.PerformLayout();
            this.groupBox_Distance.ResumeLayout(false);
            this.groupBox_Distance.PerformLayout();
            this.groupBox_Result.ResumeLayout(false);
            this.groupBox_Result.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Buttons;
        private System.Windows.Forms.Button button_Clear;
        private System.Windows.Forms.Button button_GoCalc;
        private System.Windows.Forms.Button button_Back;
        private System.Windows.Forms.GroupBox groupBox_RollingStock;
        private System.Windows.Forms.TextBox textBox_NumberOfWagons;
        private System.Windows.Forms.Label label_NumberOfWagons;
        private System.Windows.Forms.TextBox textBox_WagonCapacity;
        private System.Windows.Forms.Label label_WagonCapacity;
        private System.Windows.Forms.ComboBox comboBox_WagonModel;
        private System.Windows.Forms.Label label_WagonModel;
        private System.Windows.Forms.GroupBox groupBox_Loader;
        private System.Windows.Forms.TextBox textBox_AverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.Label label_AverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.TextBox textBox_AverageBucketFillingTime;
        private System.Windows.Forms.Label label_AverageBucketFillingTime;
        private System.Windows.Forms.TextBox textBox_BucketSpeedWithLoad;
        private System.Windows.Forms.Label label_BucketSpeedWithLoad;
        private System.Windows.Forms.TextBox textBox_BucketSpeedWithoutLoad;
        private System.Windows.Forms.Label label_BucketSpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_BucketTipTime;
        private System.Windows.Forms.Label label_BucketTipTime;
        private System.Windows.Forms.TextBox textBox_LoadedSpeed;
        private System.Windows.Forms.Label label_LoadedSpeed;
        private System.Windows.Forms.TextBox textBox_SpeedWithoutLoad;
        private System.Windows.Forms.Label label_SpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_BucketVolume;
        private System.Windows.Forms.Label label_BucketVolume;
        private System.Windows.Forms.TextBox textBox_LoaderCapacity;
        private System.Windows.Forms.Label label_LoaderCapacity;
        private System.Windows.Forms.ComboBox comboBox_LoaderBrand;
        private System.Windows.Forms.Label label_LoaderBrand;
        private System.Windows.Forms.GroupBox groupBox_Report;
        private System.Windows.Forms.TextBox textBox_ReportName;
        private System.Windows.Forms.Label label_ReportName;
        private System.Windows.Forms.Button button_SaveReport;
        private System.Windows.Forms.GroupBox groupBox_Distance;
        private System.Windows.Forms.TextBox textBox_L5;
        private System.Windows.Forms.Label label_L5;
        private System.Windows.Forms.TextBox textBox_L4;
        private System.Windows.Forms.Label label_L4;
        private System.Windows.Forms.TextBox textBox_L3;
        private System.Windows.Forms.Label label_L3;
        private System.Windows.Forms.TextBox textBox_L2;
        private System.Windows.Forms.Label label_L2;
        private System.Windows.Forms.GroupBox groupBox_Result;
        private System.Windows.Forms.TextBox textBox_ResL5;
        private System.Windows.Forms.Label label_ResL5;
        private System.Windows.Forms.TextBox textBox_ResL4;
        private System.Windows.Forms.Label label_ResL4;
        private System.Windows.Forms.TextBox textBox_ResL3;
        private System.Windows.Forms.Label label_ResL3;
        private System.Windows.Forms.TextBox textBox_ResL2;
        private System.Windows.Forms.Label label_ResL2;
        private System.Windows.Forms.TextBox textBox_ResAverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.Label label_ResAverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.TextBox textBox_ResAverageBucketFillingTime;
        private System.Windows.Forms.Label label_ResAverageBucketFillingTime;
        private System.Windows.Forms.TextBox textBox_ResBucketSpeedWithoutLoad;
        private System.Windows.Forms.Label label_ResBucketSpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_ResBucketSpeedWithLoad;
        private System.Windows.Forms.Label label_ResBucketSpeedWithLoad;
        private System.Windows.Forms.TextBox textBox_ResBucketTipTime;
        private System.Windows.Forms.Label label_ResBucketTipTime;
        private System.Windows.Forms.TextBox textBox_ResLoadedSpeed;
        private System.Windows.Forms.Label label_ResLoadedSpeed;
        private System.Windows.Forms.TextBox textBox_ResSpeedWithoutLoad;
        private System.Windows.Forms.Label label_ResSpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_ResBucketVolume;
        private System.Windows.Forms.Label label_ResBucketVolume;
        private System.Windows.Forms.TextBox textBox_ResLoaderCapacity;
        private System.Windows.Forms.Label label_ResLoaderCapacity;
        private System.Windows.Forms.TextBox textBox_ResLoaderBrand;
        private System.Windows.Forms.Label label_ResLoaderBrand;
        private System.Windows.Forms.TextBox textBox_ResWagonCapacity;
        private System.Windows.Forms.Label label_ResNumberOfWagons;
        private System.Windows.Forms.TextBox textBox_ResNumberOfWagons;
        private System.Windows.Forms.Label label_ResWagonCapacity;
        private System.Windows.Forms.TextBox textBox_ResWagonModel;
        private System.Windows.Forms.Label label_ResWagonModel;
        private System.Windows.Forms.TextBox textBox_ResReportName;
        private System.Windows.Forms.Label label_ResReportName;
        private System.Windows.Forms.Label label_TechnicalLoaderPerformance;
        private System.Windows.Forms.TextBox textBox_LoaderCycle;
        private System.Windows.Forms.Label label_LoaderCycle;
        private System.Windows.Forms.TextBox textBox_LoaderPerformance;
        private System.Windows.Forms.Label label_LoaderPerformance;
        private System.Windows.Forms.TextBox textBox_TechnicalLoaderPerformance;
        private System.Windows.Forms.TextBox textBox_TrainServiceTime;
        private System.Windows.Forms.Label label_TrainServiceTime;
        private System.Windows.Forms.TextBox textBox_WagonServiceTime;
        private System.Windows.Forms.Label label_WagonServiceTime;
        private System.Windows.Forms.TextBox textBox_SideHeight;
        private System.Windows.Forms.Label label_SideHeight;
        private System.Windows.Forms.TextBox textBox_ResSideHeight;
        private System.Windows.Forms.Label label_ResSideHeight;
        private System.Windows.Forms.Button button_NewCalc;
        private System.Windows.Forms.TextBox textBox_WagonID;
        private System.Windows.Forms.TextBox textBox_LoaderID;
    }
}