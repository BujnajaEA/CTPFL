﻿namespace CTPFL
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.button_Calc = new System.Windows.Forms.Button();
            this.button_Loader = new System.Windows.Forms.Button();
            this.button_Report = new System.Windows.Forms.Button();
            this.button_Wagon = new System.Windows.Forms.Button();
            this.groupBox_Buttons = new System.Windows.Forms.GroupBox();
            this.groupBox_Buttons.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Calc
            // 
            this.button_Calc.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Calc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Calc.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Calc.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Calc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Calc.Location = new System.Drawing.Point(5, 30);
            this.button_Calc.Margin = new System.Windows.Forms.Padding(0);
            this.button_Calc.Name = "button_Calc";
            this.button_Calc.Size = new System.Drawing.Size(240, 35);
            this.button_Calc.TabIndex = 0;
            this.button_Calc.Text = "Расчет";
            this.button_Calc.UseVisualStyleBackColor = false;
            this.button_Calc.Click += new System.EventHandler(this.button_Calc_Click);
            // 
            // button_Loader
            // 
            this.button_Loader.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Loader.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Loader.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Loader.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Loader.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Loader.Location = new System.Drawing.Point(5, 65);
            this.button_Loader.Margin = new System.Windows.Forms.Padding(0);
            this.button_Loader.Name = "button_Loader";
            this.button_Loader.Size = new System.Drawing.Size(240, 35);
            this.button_Loader.TabIndex = 1;
            this.button_Loader.Text = "Погрузчик";
            this.button_Loader.UseVisualStyleBackColor = false;
            this.button_Loader.Click += new System.EventHandler(this.button_Loader_Click);
            // 
            // button_Report
            // 
            this.button_Report.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Report.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Report.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Report.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Report.Location = new System.Drawing.Point(5, 100);
            this.button_Report.Margin = new System.Windows.Forms.Padding(0);
            this.button_Report.Name = "button_Report";
            this.button_Report.Size = new System.Drawing.Size(240, 35);
            this.button_Report.TabIndex = 2;
            this.button_Report.Text = "Отчет";
            this.button_Report.UseVisualStyleBackColor = false;
            this.button_Report.Click += new System.EventHandler(this.button_Report_Click);
            // 
            // button_Wagon
            // 
            this.button_Wagon.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Wagon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Wagon.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Wagon.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Wagon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Wagon.Location = new System.Drawing.Point(5, 135);
            this.button_Wagon.Margin = new System.Windows.Forms.Padding(0);
            this.button_Wagon.Name = "button_Wagon";
            this.button_Wagon.Size = new System.Drawing.Size(240, 35);
            this.button_Wagon.TabIndex = 3;
            this.button_Wagon.Text = "Вагон";
            this.button_Wagon.UseVisualStyleBackColor = false;
            this.button_Wagon.Click += new System.EventHandler(this.button_Wagon_Click);
            // 
            // groupBox_Buttons
            // 
            this.groupBox_Buttons.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox_Buttons.Controls.Add(this.button_Wagon);
            this.groupBox_Buttons.Controls.Add(this.button_Report);
            this.groupBox_Buttons.Controls.Add(this.button_Loader);
            this.groupBox_Buttons.Controls.Add(this.button_Calc);
            this.groupBox_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox_Buttons.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Buttons.Location = new System.Drawing.Point(1330, 0);
            this.groupBox_Buttons.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Name = "groupBox_Buttons";
            this.groupBox_Buttons.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Size = new System.Drawing.Size(250, 817);
            this.groupBox_Buttons.TabIndex = 0;
            this.groupBox_Buttons.TabStop = false;
            this.groupBox_Buttons.Text = "Выберите действие";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::CTPFL.Properties.Resources.main;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1580, 817);
            this.Controls.Add(this.groupBox_Buttons);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Главное меню";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.groupBox_Buttons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Calc;
        private System.Windows.Forms.Button button_Loader;
        private System.Windows.Forms.Button button_Report;
        private System.Windows.Forms.Button button_Wagon;
        private System.Windows.Forms.GroupBox groupBox_Buttons;
    }
}

