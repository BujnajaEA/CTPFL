﻿namespace CTPFL
{
    partial class FormWagon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormWagon));
            this.groupBox_Buttons = new System.Windows.Forms.GroupBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_Add = new System.Windows.Forms.Button();
            this.button_Back = new System.Windows.Forms.Button();
            this.groupBox_AddOrEdit = new System.Windows.Forms.GroupBox();
            this.textBox_WagonModel = new System.Windows.Forms.TextBox();
            this.textBox_SideHeight = new System.Windows.Forms.TextBox();
            this.label_SideHeight = new System.Windows.Forms.Label();
            this.textBox_WagonCapacity = new System.Windows.Forms.TextBox();
            this.label_WagonCapacity = new System.Windows.Forms.Label();
            this.label_WagonModel = new System.Windows.Forms.Label();
            this.dataGridView_Wagon = new System.Windows.Forms.DataGridView();
            this.groupBox_Buttons.SuspendLayout();
            this.groupBox_AddOrEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Wagon)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_Buttons
            // 
            this.groupBox_Buttons.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox_Buttons.Controls.Add(this.button_Delete);
            this.groupBox_Buttons.Controls.Add(this.button_Edit);
            this.groupBox_Buttons.Controls.Add(this.button_Add);
            this.groupBox_Buttons.Controls.Add(this.button_Back);
            this.groupBox_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox_Buttons.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Buttons.Location = new System.Drawing.Point(1341, 0);
            this.groupBox_Buttons.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Name = "groupBox_Buttons";
            this.groupBox_Buttons.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Size = new System.Drawing.Size(250, 813);
            this.groupBox_Buttons.TabIndex = 3;
            this.groupBox_Buttons.TabStop = false;
            this.groupBox_Buttons.Text = "Выберите действие";
            this.groupBox_Buttons.Enter += new System.EventHandler(this.groupBox_Buttons_Enter);
            // 
            // button_Delete
            // 
            this.button_Delete.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Delete.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Delete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Delete.Location = new System.Drawing.Point(5, 135);
            this.button_Delete.Margin = new System.Windows.Forms.Padding(0);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(240, 35);
            this.button_Delete.TabIndex = 3;
            this.button_Delete.Text = "Удалить";
            this.button_Delete.UseVisualStyleBackColor = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Edit.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Edit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Edit.Location = new System.Drawing.Point(5, 100);
            this.button_Edit.Margin = new System.Windows.Forms.Padding(0);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(240, 35);
            this.button_Edit.TabIndex = 2;
            this.button_Edit.Text = "Редактировать";
            this.button_Edit.UseVisualStyleBackColor = false;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_Add
            // 
            this.button_Add.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Add.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Add.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Add.Location = new System.Drawing.Point(5, 65);
            this.button_Add.Margin = new System.Windows.Forms.Padding(0);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(240, 35);
            this.button_Add.TabIndex = 1;
            this.button_Add.Text = "Добавить";
            this.button_Add.UseVisualStyleBackColor = false;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // button_Back
            // 
            this.button_Back.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Back.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Back.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Back.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Back.Location = new System.Drawing.Point(5, 30);
            this.button_Back.Margin = new System.Windows.Forms.Padding(0);
            this.button_Back.Name = "button_Back";
            this.button_Back.Size = new System.Drawing.Size(240, 35);
            this.button_Back.TabIndex = 0;
            this.button_Back.Text = "Вернуться в меню";
            this.button_Back.UseVisualStyleBackColor = false;
            this.button_Back.Click += new System.EventHandler(this.button_Back_Click);
            // 
            // groupBox_AddOrEdit
            // 
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_WagonModel);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_SideHeight);
            this.groupBox_AddOrEdit.Controls.Add(this.label_SideHeight);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_WagonCapacity);
            this.groupBox_AddOrEdit.Controls.Add(this.label_WagonCapacity);
            this.groupBox_AddOrEdit.Controls.Add(this.label_WagonModel);
            this.groupBox_AddOrEdit.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_AddOrEdit.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_AddOrEdit.Location = new System.Drawing.Point(0, 0);
            this.groupBox_AddOrEdit.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_AddOrEdit.Name = "groupBox_AddOrEdit";
            this.groupBox_AddOrEdit.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_AddOrEdit.Size = new System.Drawing.Size(1341, 117);
            this.groupBox_AddOrEdit.TabIndex = 5;
            this.groupBox_AddOrEdit.TabStop = false;
            this.groupBox_AddOrEdit.Text = "Введите данные вагона и нажмите кнопку добавить/редактировать";
            // 
            // textBox_WagonModel
            // 
            this.textBox_WagonModel.Location = new System.Drawing.Point(148, 45);
            this.textBox_WagonModel.Name = "textBox_WagonModel";
            this.textBox_WagonModel.Size = new System.Drawing.Size(161, 29);
            this.textBox_WagonModel.TabIndex = 23;
            // 
            // textBox_SideHeight
            // 
            this.textBox_SideHeight.Location = new System.Drawing.Point(741, 45);
            this.textBox_SideHeight.Name = "textBox_SideHeight";
            this.textBox_SideHeight.Size = new System.Drawing.Size(85, 29);
            this.textBox_SideHeight.TabIndex = 8;
            // 
            // label_SideHeight
            // 
            this.label_SideHeight.AutoSize = true;
            this.label_SideHeight.Location = new System.Drawing.Point(592, 48);
            this.label_SideHeight.Name = "label_SideHeight";
            this.label_SideHeight.Size = new System.Drawing.Size(143, 21);
            this.label_SideHeight.TabIndex = 7;
            this.label_SideHeight.Text = "Высота борта, м";
            // 
            // textBox_WagonCapacity
            // 
            this.textBox_WagonCapacity.Location = new System.Drawing.Point(501, 45);
            this.textBox_WagonCapacity.Name = "textBox_WagonCapacity";
            this.textBox_WagonCapacity.Size = new System.Drawing.Size(85, 29);
            this.textBox_WagonCapacity.TabIndex = 6;
            // 
            // label_WagonCapacity
            // 
            this.label_WagonCapacity.AutoSize = true;
            this.label_WagonCapacity.Location = new System.Drawing.Point(315, 48);
            this.label_WagonCapacity.Name = "label_WagonCapacity";
            this.label_WagonCapacity.Size = new System.Drawing.Size(180, 21);
            this.label_WagonCapacity.TabIndex = 3;
            this.label_WagonCapacity.Text = "Грузоподъемность, т";
            // 
            // label_WagonModel
            // 
            this.label_WagonModel.AutoSize = true;
            this.label_WagonModel.Location = new System.Drawing.Point(13, 48);
            this.label_WagonModel.Name = "label_WagonModel";
            this.label_WagonModel.Size = new System.Drawing.Size(129, 21);
            this.label_WagonModel.TabIndex = 1;
            this.label_WagonModel.Text = "Модель вагона";
            // 
            // dataGridView_Wagon
            // 
            this.dataGridView_Wagon.AllowUserToAddRows = false;
            this.dataGridView_Wagon.AllowUserToDeleteRows = false;
            this.dataGridView_Wagon.AllowUserToOrderColumns = true;
            this.dataGridView_Wagon.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView_Wagon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Wagon.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView_Wagon.Location = new System.Drawing.Point(0, 117);
            this.dataGridView_Wagon.Name = "dataGridView_Wagon";
            this.dataGridView_Wagon.ReadOnly = true;
            this.dataGridView_Wagon.Size = new System.Drawing.Size(1341, 180);
            this.dataGridView_Wagon.TabIndex = 6;
            // 
            // FormWagon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1591, 813);
            this.Controls.Add(this.dataGridView_Wagon);
            this.Controls.Add(this.groupBox_AddOrEdit);
            this.Controls.Add(this.groupBox_Buttons);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormWagon";
            this.Text = "Редактирование параметров вагона";
            this.Load += new System.EventHandler(this.FormWagon_Load);
            this.groupBox_Buttons.ResumeLayout(false);
            this.groupBox_AddOrEdit.ResumeLayout(false);
            this.groupBox_AddOrEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Wagon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Buttons;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Button button_Back;
        private System.Windows.Forms.GroupBox groupBox_AddOrEdit;
        private System.Windows.Forms.TextBox textBox_WagonModel;
        private System.Windows.Forms.TextBox textBox_SideHeight;
        private System.Windows.Forms.Label label_SideHeight;
        private System.Windows.Forms.TextBox textBox_WagonCapacity;
        private System.Windows.Forms.Label label_WagonCapacity;
        private System.Windows.Forms.Label label_WagonModel;
        private System.Windows.Forms.DataGridView dataGridView_Wagon;
    }
}