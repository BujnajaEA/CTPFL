﻿namespace CTPFL
{
    partial class FormLoader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLoader));
            this.groupBox_Buttons = new System.Windows.Forms.GroupBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_Add = new System.Windows.Forms.Button();
            this.button_Back = new System.Windows.Forms.Button();
            this.groupBox_AddOrEdit = new System.Windows.Forms.GroupBox();
            this.textBox_LoaderBrand = new System.Windows.Forms.TextBox();
            this.textBox_AverageDumpingTimeFromTheBucket = new System.Windows.Forms.TextBox();
            this.label_AverageDumpingTimeFromTheBucket = new System.Windows.Forms.Label();
            this.textBox_AverageBucketFillingTime = new System.Windows.Forms.TextBox();
            this.label_AverageBucketFillingTime = new System.Windows.Forms.Label();
            this.textBox_BucketSpeedWithLoad = new System.Windows.Forms.TextBox();
            this.label_BucketSpeedWithLoad = new System.Windows.Forms.Label();
            this.textBox_BucketSpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_BucketSpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_BucketTipTime = new System.Windows.Forms.TextBox();
            this.label_BucketTipTime = new System.Windows.Forms.Label();
            this.textBox_LoadedSpeed = new System.Windows.Forms.TextBox();
            this.label_LoadedSpeed = new System.Windows.Forms.Label();
            this.textBox_SpeedWithoutLoad = new System.Windows.Forms.TextBox();
            this.label_SpeedWithoutLoad = new System.Windows.Forms.Label();
            this.textBox_BucketVolume = new System.Windows.Forms.TextBox();
            this.label_BucketVolume = new System.Windows.Forms.Label();
            this.textBox_LoaderCapacity = new System.Windows.Forms.TextBox();
            this.label_LoaderCapacity = new System.Windows.Forms.Label();
            this.label_LoaderBrand = new System.Windows.Forms.Label();
            this.dataGridView_Loader = new System.Windows.Forms.DataGridView();
            this.groupBox_Buttons.SuspendLayout();
            this.groupBox_AddOrEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Loader)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_Buttons
            // 
            this.groupBox_Buttons.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox_Buttons.Controls.Add(this.button_Delete);
            this.groupBox_Buttons.Controls.Add(this.button_Edit);
            this.groupBox_Buttons.Controls.Add(this.button_Add);
            this.groupBox_Buttons.Controls.Add(this.button_Back);
            this.groupBox_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox_Buttons.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Buttons.Location = new System.Drawing.Point(1338, 0);
            this.groupBox_Buttons.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Name = "groupBox_Buttons";
            this.groupBox_Buttons.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Size = new System.Drawing.Size(250, 815);
            this.groupBox_Buttons.TabIndex = 2;
            this.groupBox_Buttons.TabStop = false;
            this.groupBox_Buttons.Text = "Выберите действие";
            // 
            // button_Delete
            // 
            this.button_Delete.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Delete.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Delete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Delete.Location = new System.Drawing.Point(5, 135);
            this.button_Delete.Margin = new System.Windows.Forms.Padding(0);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(240, 35);
            this.button_Delete.TabIndex = 3;
            this.button_Delete.Text = "Удалить";
            this.button_Delete.UseVisualStyleBackColor = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Edit.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Edit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Edit.Location = new System.Drawing.Point(5, 100);
            this.button_Edit.Margin = new System.Windows.Forms.Padding(0);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(240, 35);
            this.button_Edit.TabIndex = 2;
            this.button_Edit.Text = "Редактировать";
            this.button_Edit.UseVisualStyleBackColor = false;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_Add
            // 
            this.button_Add.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Add.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Add.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Add.Location = new System.Drawing.Point(5, 65);
            this.button_Add.Margin = new System.Windows.Forms.Padding(0);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(240, 35);
            this.button_Add.TabIndex = 1;
            this.button_Add.Text = "Добавить";
            this.button_Add.UseVisualStyleBackColor = false;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // button_Back
            // 
            this.button_Back.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Back.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Back.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Back.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Back.Location = new System.Drawing.Point(5, 30);
            this.button_Back.Margin = new System.Windows.Forms.Padding(0);
            this.button_Back.Name = "button_Back";
            this.button_Back.Size = new System.Drawing.Size(240, 35);
            this.button_Back.TabIndex = 0;
            this.button_Back.Text = "Вернуться в меню";
            this.button_Back.UseVisualStyleBackColor = false;
            this.button_Back.Click += new System.EventHandler(this.button_Back_Click);
            // 
            // groupBox_AddOrEdit
            // 
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_LoaderBrand);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_AverageDumpingTimeFromTheBucket);
            this.groupBox_AddOrEdit.Controls.Add(this.label_AverageDumpingTimeFromTheBucket);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_AverageBucketFillingTime);
            this.groupBox_AddOrEdit.Controls.Add(this.label_AverageBucketFillingTime);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_BucketSpeedWithLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.label_BucketSpeedWithLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_BucketSpeedWithoutLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.label_BucketSpeedWithoutLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_BucketTipTime);
            this.groupBox_AddOrEdit.Controls.Add(this.label_BucketTipTime);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_LoadedSpeed);
            this.groupBox_AddOrEdit.Controls.Add(this.label_LoadedSpeed);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_SpeedWithoutLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.label_SpeedWithoutLoad);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_BucketVolume);
            this.groupBox_AddOrEdit.Controls.Add(this.label_BucketVolume);
            this.groupBox_AddOrEdit.Controls.Add(this.textBox_LoaderCapacity);
            this.groupBox_AddOrEdit.Controls.Add(this.label_LoaderCapacity);
            this.groupBox_AddOrEdit.Controls.Add(this.label_LoaderBrand);
            this.groupBox_AddOrEdit.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_AddOrEdit.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_AddOrEdit.Location = new System.Drawing.Point(0, 0);
            this.groupBox_AddOrEdit.Margin = new System.Windows.Forms.Padding(10);
            this.groupBox_AddOrEdit.Name = "groupBox_AddOrEdit";
            this.groupBox_AddOrEdit.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_AddOrEdit.Size = new System.Drawing.Size(1338, 188);
            this.groupBox_AddOrEdit.TabIndex = 4;
            this.groupBox_AddOrEdit.TabStop = false;
            this.groupBox_AddOrEdit.Text = "Введите данные погрузчика и нажмите кнопку добавить/редактировать";
            // 
            // textBox_LoaderBrand
            // 
            this.textBox_LoaderBrand.Location = new System.Drawing.Point(181, 29);
            this.textBox_LoaderBrand.Name = "textBox_LoaderBrand";
            this.textBox_LoaderBrand.Size = new System.Drawing.Size(161, 29);
            this.textBox_LoaderBrand.TabIndex = 23;
            // 
            // textBox_AverageDumpingTimeFromTheBucket
            // 
            this.textBox_AverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(1143, 110);
            this.textBox_AverageDumpingTimeFromTheBucket.Name = "textBox_AverageDumpingTimeFromTheBucket";
            this.textBox_AverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(85, 29);
            this.textBox_AverageDumpingTimeFromTheBucket.TabIndex = 22;
            // 
            // label_AverageDumpingTimeFromTheBucket
            // 
            this.label_AverageDumpingTimeFromTheBucket.AutoSize = true;
            this.label_AverageDumpingTimeFromTheBucket.Location = new System.Drawing.Point(767, 113);
            this.label_AverageDumpingTimeFromTheBucket.Name = "label_AverageDumpingTimeFromTheBucket";
            this.label_AverageDumpingTimeFromTheBucket.Size = new System.Drawing.Size(370, 21);
            this.label_AverageDumpingTimeFromTheBucket.TabIndex = 21;
            this.label_AverageDumpingTimeFromTheBucket.Text = "Среднее время высыпания груза из ковша, с";
            // 
            // textBox_AverageBucketFillingTime
            // 
            this.textBox_AverageBucketFillingTime.Location = new System.Drawing.Point(676, 110);
            this.textBox_AverageBucketFillingTime.Name = "textBox_AverageBucketFillingTime";
            this.textBox_AverageBucketFillingTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_AverageBucketFillingTime.TabIndex = 20;
            // 
            // label_AverageBucketFillingTime
            // 
            this.label_AverageBucketFillingTime.AutoSize = true;
            this.label_AverageBucketFillingTime.Location = new System.Drawing.Point(370, 113);
            this.label_AverageBucketFillingTime.Name = "label_AverageBucketFillingTime";
            this.label_AverageBucketFillingTime.Size = new System.Drawing.Size(300, 21);
            this.label_AverageBucketFillingTime.TabIndex = 19;
            this.label_AverageBucketFillingTime.Text = "Среднее время заполнения ковша, с";
            // 
            // textBox_BucketSpeedWithLoad
            // 
            this.textBox_BucketSpeedWithLoad.Location = new System.Drawing.Point(942, 72);
            this.textBox_BucketSpeedWithLoad.Name = "textBox_BucketSpeedWithLoad";
            this.textBox_BucketSpeedWithLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketSpeedWithLoad.TabIndex = 18;
            // 
            // label_BucketSpeedWithLoad
            // 
            this.label_BucketSpeedWithLoad.AutoSize = true;
            this.label_BucketSpeedWithLoad.Location = new System.Drawing.Point(683, 75);
            this.label_BucketSpeedWithLoad.Name = "label_BucketSpeedWithLoad";
            this.label_BucketSpeedWithLoad.Size = new System.Drawing.Size(253, 21);
            this.label_BucketSpeedWithLoad.TabIndex = 17;
            this.label_BucketSpeedWithLoad.Text = "Скорость ковша с грузом, м/с";
            // 
            // textBox_BucketSpeedWithoutLoad
            // 
            this.textBox_BucketSpeedWithoutLoad.Location = new System.Drawing.Point(279, 110);
            this.textBox_BucketSpeedWithoutLoad.Name = "textBox_BucketSpeedWithoutLoad";
            this.textBox_BucketSpeedWithoutLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketSpeedWithoutLoad.TabIndex = 16;
            // 
            // label_BucketSpeedWithoutLoad
            // 
            this.label_BucketSpeedWithoutLoad.AutoSize = true;
            this.label_BucketSpeedWithoutLoad.Location = new System.Drawing.Point(17, 113);
            this.label_BucketSpeedWithoutLoad.Name = "label_BucketSpeedWithoutLoad";
            this.label_BucketSpeedWithoutLoad.Size = new System.Drawing.Size(256, 21);
            this.label_BucketSpeedWithoutLoad.TabIndex = 15;
            this.label_BucketSpeedWithoutLoad.Text = "Скорость ковша без груза, м/с";
            // 
            // textBox_BucketTipTime
            // 
            this.textBox_BucketTipTime.Location = new System.Drawing.Point(592, 72);
            this.textBox_BucketTipTime.Name = "textBox_BucketTipTime";
            this.textBox_BucketTipTime.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketTipTime.TabIndex = 14;
            // 
            // label_BucketTipTime
            // 
            this.label_BucketTipTime.AutoSize = true;
            this.label_BucketTipTime.Location = new System.Drawing.Point(313, 75);
            this.label_BucketTipTime.Name = "label_BucketTipTime";
            this.label_BucketTipTime.Size = new System.Drawing.Size(273, 21);
            this.label_BucketTipTime.TabIndex = 13;
            this.label_BucketTipTime.Text = "Время запрокидывания ковша, с";
            // 
            // textBox_LoadedSpeed
            // 
            this.textBox_LoadedSpeed.Location = new System.Drawing.Point(222, 72);
            this.textBox_LoadedSpeed.Name = "textBox_LoadedSpeed";
            this.textBox_LoadedSpeed.Size = new System.Drawing.Size(85, 29);
            this.textBox_LoadedSpeed.TabIndex = 12;
            // 
            // label_LoadedSpeed
            // 
            this.label_LoadedSpeed.AutoSize = true;
            this.label_LoadedSpeed.Location = new System.Drawing.Point(17, 75);
            this.label_LoadedSpeed.Name = "label_LoadedSpeed";
            this.label_LoadedSpeed.Size = new System.Drawing.Size(199, 21);
            this.label_LoadedSpeed.TabIndex = 11;
            this.label_LoadedSpeed.Text = "Скорость с грузом, м/с";
            // 
            // textBox_SpeedWithoutLoad
            // 
            this.textBox_SpeedWithoutLoad.Location = new System.Drawing.Point(1087, 29);
            this.textBox_SpeedWithoutLoad.Name = "textBox_SpeedWithoutLoad";
            this.textBox_SpeedWithoutLoad.Size = new System.Drawing.Size(85, 29);
            this.textBox_SpeedWithoutLoad.TabIndex = 10;
            // 
            // label_SpeedWithoutLoad
            // 
            this.label_SpeedWithoutLoad.AutoSize = true;
            this.label_SpeedWithoutLoad.Location = new System.Drawing.Point(879, 32);
            this.label_SpeedWithoutLoad.Name = "label_SpeedWithoutLoad";
            this.label_SpeedWithoutLoad.Size = new System.Drawing.Size(202, 21);
            this.label_SpeedWithoutLoad.TabIndex = 9;
            this.label_SpeedWithoutLoad.Text = "Скорость без груза, м/с";
            // 
            // textBox_BucketVolume
            // 
            this.textBox_BucketVolume.Location = new System.Drawing.Point(788, 29);
            this.textBox_BucketVolume.Name = "textBox_BucketVolume";
            this.textBox_BucketVolume.Size = new System.Drawing.Size(85, 29);
            this.textBox_BucketVolume.TabIndex = 8;
            // 
            // label_BucketVolume
            // 
            this.label_BucketVolume.AutoSize = true;
            this.label_BucketVolume.Location = new System.Drawing.Point(625, 32);
            this.label_BucketVolume.Name = "label_BucketVolume";
            this.label_BucketVolume.Size = new System.Drawing.Size(157, 21);
            this.label_BucketVolume.TabIndex = 7;
            this.label_BucketVolume.Text = "Объем ковша, м^3";
            // 
            // textBox_LoaderCapacity
            // 
            this.textBox_LoaderCapacity.Location = new System.Drawing.Point(534, 29);
            this.textBox_LoaderCapacity.Name = "textBox_LoaderCapacity";
            this.textBox_LoaderCapacity.Size = new System.Drawing.Size(85, 29);
            this.textBox_LoaderCapacity.TabIndex = 6;
            // 
            // label_LoaderCapacity
            // 
            this.label_LoaderCapacity.AutoSize = true;
            this.label_LoaderCapacity.Location = new System.Drawing.Point(348, 32);
            this.label_LoaderCapacity.Name = "label_LoaderCapacity";
            this.label_LoaderCapacity.Size = new System.Drawing.Size(180, 21);
            this.label_LoaderCapacity.TabIndex = 3;
            this.label_LoaderCapacity.Text = "Грузоподъемность, т";
            // 
            // label_LoaderBrand
            // 
            this.label_LoaderBrand.AutoSize = true;
            this.label_LoaderBrand.Location = new System.Drawing.Point(17, 32);
            this.label_LoaderBrand.Name = "label_LoaderBrand";
            this.label_LoaderBrand.Size = new System.Drawing.Size(158, 21);
            this.label_LoaderBrand.TabIndex = 1;
            this.label_LoaderBrand.Text = "Марка погрузчика";
            // 
            // dataGridView_Loader
            // 
            this.dataGridView_Loader.AllowUserToAddRows = false;
            this.dataGridView_Loader.AllowUserToDeleteRows = false;
            this.dataGridView_Loader.AllowUserToOrderColumns = true;
            this.dataGridView_Loader.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView_Loader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Loader.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView_Loader.Location = new System.Drawing.Point(0, 188);
            this.dataGridView_Loader.Name = "dataGridView_Loader";
            this.dataGridView_Loader.ReadOnly = true;
            this.dataGridView_Loader.Size = new System.Drawing.Size(1338, 180);
            this.dataGridView_Loader.TabIndex = 5;
            // 
            // FormLoader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1588, 815);
            this.Controls.Add(this.dataGridView_Loader);
            this.Controls.Add(this.groupBox_AddOrEdit);
            this.Controls.Add(this.groupBox_Buttons);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormLoader";
            this.Text = "Редактирование параметров погрузчика";
            this.groupBox_Buttons.ResumeLayout(false);
            this.groupBox_AddOrEdit.ResumeLayout(false);
            this.groupBox_AddOrEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Loader)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Buttons;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Button button_Back;
        private System.Windows.Forms.GroupBox groupBox_AddOrEdit;
        private System.Windows.Forms.TextBox textBox_AverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.Label label_AverageDumpingTimeFromTheBucket;
        private System.Windows.Forms.TextBox textBox_AverageBucketFillingTime;
        private System.Windows.Forms.Label label_AverageBucketFillingTime;
        private System.Windows.Forms.TextBox textBox_BucketSpeedWithLoad;
        private System.Windows.Forms.Label label_BucketSpeedWithLoad;
        private System.Windows.Forms.TextBox textBox_BucketSpeedWithoutLoad;
        private System.Windows.Forms.Label label_BucketSpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_BucketTipTime;
        private System.Windows.Forms.Label label_BucketTipTime;
        private System.Windows.Forms.TextBox textBox_LoadedSpeed;
        private System.Windows.Forms.Label label_LoadedSpeed;
        private System.Windows.Forms.TextBox textBox_SpeedWithoutLoad;
        private System.Windows.Forms.Label label_SpeedWithoutLoad;
        private System.Windows.Forms.TextBox textBox_BucketVolume;
        private System.Windows.Forms.Label label_BucketVolume;
        private System.Windows.Forms.TextBox textBox_LoaderCapacity;
        private System.Windows.Forms.Label label_LoaderCapacity;
        private System.Windows.Forms.Label label_LoaderBrand;
        private System.Windows.Forms.DataGridView dataGridView_Loader;
        private System.Windows.Forms.TextBox textBox_LoaderBrand;
    }
}