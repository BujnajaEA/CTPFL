﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace CTPFL
{
    public partial class FormCalc : Form
    {
        string connectionString = @"Data Source=DESKTOP-L5BOSMO;initial catalog=D_CTPFL;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;";
        
        private FormMain _fmain;

        public FormCalc(FormMain fmain)
        {
            InitializeComponent();

            _fmain = fmain;
        }

        private void button_Back_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _fmain.Visible = true;
        }

        private void button_GoCalc_Click(object sender, EventArgs e)
        {
            groupBox_RollingStock.Visible = false;
            groupBox_Loader.Visible = false;
            groupBox_Report.Visible = false;
            groupBox_Distance.Visible = false;
            groupBox_Result.Visible = true;
            button_GoCalc.Visible = false;
            button_Clear.Visible = false;
            button_SaveReport.Visible = true;
            button_NewCalc.Visible = true;
            string reportName = textBox_ReportName.Text;// название отчета
            string wagonModel = comboBox_WagonModel.Text;// модель вагона
            double wagonCapacity = Convert.ToDouble(textBox_WagonCapacity.Text);// груз-ть вагона
            double sideHeight = Convert.ToDouble(textBox_SideHeight.Text); // высота борта вагона
            string numberOfWagons = textBox_NumberOfWagons.Text;// кол-во вагонов
            string loaderBrand = comboBox_LoaderBrand.Text;// марка погрузчика
            double loaderCapacity = Convert.ToDouble(textBox_LoaderCapacity.Text);// груз-ть погрузчика
            double bucketVolume = Convert.ToDouble(textBox_BucketVolume.Text);// объем ковша
            double speedWithoutLoad = Convert.ToDouble(textBox_SpeedWithoutLoad.Text);// скорость без груза
            double loadedSpeed = Convert.ToDouble(textBox_LoadedSpeed.Text);// скорость с грузом
            double bucketTipTime = Convert.ToDouble(textBox_BucketTipTime.Text);// время запрокидывания ковша
            string bucketSpeedWithLoad = textBox_BucketSpeedWithLoad.Text;// скорость ковша с грузом
            string bucketSpeedWithoutLoad = textBox_BucketSpeedWithoutLoad.Text;// скорость ковша без груза
            double averageBucketFillingTime = Convert.ToDouble(textBox_AverageBucketFillingTime.Text);// среднее время заполнения ковша
            double averageDumpingTimeFromTheBucket = Convert.ToDouble(textBox_AverageDumpingTimeFromTheBucket.Text);// среднее время высыпания груза из ковша
            double l2 = Convert.ToDouble(textBox_L2.Text); // расстояние, на к-ое перемещается погр-к при отъезде от штабеля груза
            double l3 = Convert.ToDouble(textBox_L3.Text); // расстояние, на к-ое перемещается погр-к при подъезде к вагону
            double l4 = Convert.ToDouble(textBox_L4.Text); // расстояние, на к-ое погр-к отъезжает от вагона
            double l5 = Convert.ToDouble(textBox_L5.Text); // расстояние, на к-ое перемещается погр-к при движении к штабелю груза
            double t1 = 3.6 / speedWithoutLoad + 1.5; // наезд погр-ка на штабель груза
            double tk = averageBucketFillingTime * bucketVolume * 1.1 * 0.8;
            double t2 = tk + bucketTipTime; // копание, набор груза в ковш и его запрокидывание
            double t3 = 0.3 / Convert.ToDouble(bucketSpeedWithLoad) + 1.5; // подъем ковша в транспортное положение
            double t4 = Convert.ToDouble(l2) / loadedSpeed + 1.5; // отъезд погр-ка от штабеля с грузом
            double t5 = Convert.ToDouble(l3) / loadedSpeed + 1.5; // подъезд погр-ка к вагону
            double hp = 1.2 * sideHeight - 0.3; // высота подъема ковша для разгрузки груза
            double t6 = hp / Convert.ToDouble(bucketSpeedWithLoad) + 1.5; // подъем ковша на высоту разгрузки
            double tb = averageDumpingTimeFromTheBucket * bucketVolume * 1.1 * 0.8;
            double t7 = tb + bucketTipTime; // разгрузка ковша и его запрокидывание
            double t8 = hp / Convert.ToDouble(bucketSpeedWithoutLoad) + 1.5; // опускание ковша в транспортное положение
            double t9 = Convert.ToDouble(l4) / speedWithoutLoad + 1.5; // отъезд погр-ка от вагона
            double t10 = Convert.ToDouble(l5) / speedWithoutLoad + 1.5; // подъезд погр-ка к штабелю груза
            double loaderCycle = 0.758 * (t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10);// цикл погрузчика
            double technicalLoaderPerformance = 3600 * bucketVolume * 1.1 * 0.8 / loaderCycle;// техническая произв-ть погр-ка
            double loaderPerformance = 0.85 * technicalLoaderPerformance;// эксплуат. произв-ть погр-ка
            double wagonServiceTime = wagonCapacity / loaderCapacity * loaderCycle;// время обслуживания вагона
            double trainServiceTime = wagonServiceTime * Convert.ToDouble(numberOfWagons); // время обслуживания состава

            GetResult
                (reportName, wagonModel, wagonCapacity, sideHeight, numberOfWagons, loaderBrand, loaderCapacity, bucketVolume, speedWithoutLoad, loadedSpeed,
                bucketTipTime, bucketSpeedWithLoad, bucketSpeedWithoutLoad, averageBucketFillingTime, averageDumpingTimeFromTheBucket, l2, l3, l4, l5, loaderCycle,
                technicalLoaderPerformance, loaderPerformance, wagonServiceTime, trainServiceTime);
        }

        private void GetResult(string reportName, string wagonModel, double wagonCapacity, double sideHeight, string numberOfWagons, string loaderBrand,
            double loaderCapacity, double bucketVolume, double speedWithoutLoad, double loadedSpeed, double bucketTipTime, string bucketSpeedWithLoad, string bucketSpeedWithoutLoad,
            double averageBucketFillingTime, double averageDumpingTimeFromTheBucket, double l2, double l3, double l4, double l5, double loaderCycle, double technicalLoaderPerformance,
            double loaderPerformance, double wagonServiceTime, double trainServiceTime)
        {
            textBox_ResReportName.Text = string.Format($" {reportName}");
            textBox_ResWagonModel.Text = string.Format($" {wagonModel}");
            textBox_ResWagonCapacity.Text = string.Format($" {wagonCapacity}");
            textBox_ResSideHeight.Text = string.Format($" {sideHeight}");
            textBox_ResNumberOfWagons.Text = string.Format($" {numberOfWagons}");
            textBox_ResLoaderBrand.Text = string.Format($" {loaderBrand}");
            textBox_ResLoaderCapacity.Text = string.Format($" {loaderCapacity}");
            textBox_ResBucketVolume.Text = string.Format($" {bucketVolume}");
            textBox_ResSpeedWithoutLoad.Text = string.Format($" {speedWithoutLoad}");
            textBox_ResLoadedSpeed.Text = string.Format($" {loadedSpeed}");
            textBox_ResBucketTipTime.Text = string.Format($" {bucketTipTime}");
            textBox_ResBucketSpeedWithLoad.Text = string.Format($" {bucketSpeedWithLoad}");
            textBox_ResBucketSpeedWithoutLoad.Text = string.Format($" {bucketSpeedWithoutLoad}");
            textBox_ResAverageBucketFillingTime.Text = string.Format($" {averageBucketFillingTime}");
            textBox_ResAverageDumpingTimeFromTheBucket.Text = string.Format($" {averageDumpingTimeFromTheBucket}");
            textBox_ResL2.Text = string.Format($" {l2}");
            textBox_ResL3.Text = string.Format($" {l3}");
            textBox_ResL4.Text = string.Format($" {l4}");
            textBox_ResL5.Text = string.Format($" {l5}");

            textBox_LoaderCycle.Text = string.Format($" {Math.Round(loaderCycle, 1)}");
            textBox_TechnicalLoaderPerformance.Text = string.Format($" {Math.Round(technicalLoaderPerformance, 1)}");
            textBox_LoaderPerformance.Text = string.Format($" {Math.Round(loaderPerformance, 1)}");
            textBox_WagonServiceTime.Text = string.Format($" {Math.Round(wagonServiceTime, 1)}");
            textBox_TrainServiceTime.Text = string.Format($" {Math.Round(trainServiceTime, 1)}");
        }

        private void button_Clear_Click(object sender, EventArgs e)
        {
            textBox_ReportName.Clear();
            //comboBox_WagonModel.SelectedIndex = -1;
            textBox_WagonCapacity.Clear();
            textBox_SideHeight.Clear();
            textBox_NumberOfWagons.Clear();
            //comboBox_LoaderBrand.SelectedIndex = -1;
            textBox_LoaderCapacity.Clear();
            textBox_BucketVolume.Clear();
            textBox_SpeedWithoutLoad.Clear();
            textBox_LoadedSpeed.Clear();
            textBox_BucketTipTime.Clear();
            textBox_BucketSpeedWithLoad.Clear();
            textBox_BucketSpeedWithoutLoad.Clear();
            textBox_AverageBucketFillingTime.Clear();
            textBox_AverageDumpingTimeFromTheBucket.Clear();
            textBox_L2.Clear();
            textBox_L3.Clear();
            textBox_L4.Clear();
            textBox_L5.Clear();
            //textBox_LoaderID.Clear();
            //textBox_WagonID.Clear();
        }

        private void comboBox_WagonModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string chosenModel = comboBox_WagonModel.Text;
                connection.Open();
                SqlCommand cmdWagonCapacity = new SqlCommand($"select [Грузоподъемность, т] from Вагон where Модель_вагона = '{chosenModel}'", connection);
                double wagonCapacity = Convert.ToDouble(cmdWagonCapacity.ExecuteScalar());
                textBox_WagonCapacity.Text = string.Format(Convert.ToString(wagonCapacity));

                SqlCommand cmdSideHeight = new SqlCommand($"select [Высота_борта, м] from Вагон where Модель_вагона = '{chosenModel}'", connection);
                double sideHeight = Convert.ToDouble(cmdSideHeight.ExecuteScalar());
                textBox_SideHeight.Text = string.Format(Convert.ToString(sideHeight));

                SqlCommand cmdWagonID = new SqlCommand($"select [Код_вагона] from Вагон where Модель_вагона = '{chosenModel}'", connection);
                int wagonID = (int)cmdWagonID.ExecuteScalar();
                textBox_WagonID.Text = string.Format(Convert.ToString(wagonID));
            }
        }

        private void comboBox_LoaderBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string chosenModel = comboBox_LoaderBrand.Text;
                connection.Open();
                SqlCommand cmdLoaderCapacity = new SqlCommand($"select [Грузоподъемность_погрузчика, т] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double loaderCapacity = Convert.ToDouble(cmdLoaderCapacity.ExecuteScalar());
                textBox_LoaderCapacity.Text = string.Format(Convert.ToString(loaderCapacity));

                SqlCommand cmdBucketVolume = new SqlCommand($"select [Объем_ковша, м^3] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double bucketVolume = Convert.ToDouble(cmdBucketVolume.ExecuteScalar());
                textBox_BucketVolume.Text = string.Format(Convert.ToString(bucketVolume));

                SqlCommand cmdSpeedWithoutLoad = new SqlCommand($"select [Скорость_без_груза, м/с] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double speedWithoutLoad = Convert.ToDouble(cmdSpeedWithoutLoad.ExecuteScalar());
                textBox_SpeedWithoutLoad.Text = string.Format(Convert.ToString(speedWithoutLoad));

                SqlCommand cmdLoadedSpeed = new SqlCommand($"select [Скорость_с_грузом, м/с] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double loadedSpeed = Convert.ToDouble(cmdLoadedSpeed.ExecuteScalar());
                textBox_LoadedSpeed.Text = string.Format(Convert.ToString(loadedSpeed));

                SqlCommand cmdBucketTipTime = new SqlCommand($"select [Время_запрокидывания_ковша, с] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double bucketTipTime = Convert.ToDouble(cmdBucketTipTime.ExecuteScalar());
                textBox_BucketTipTime.Text = string.Format(Convert.ToString(bucketTipTime));

                SqlCommand cmdBucketSpeedWithLoad = new SqlCommand($"select [Скорость_подъема/опускания_ковша_с_грузом, м/с] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double bucketSpeedWithLoad = Convert.ToDouble(cmdBucketSpeedWithLoad.ExecuteScalar());
                textBox_BucketSpeedWithLoad.Text = string.Format(Convert.ToString(bucketSpeedWithLoad));

                SqlCommand cmdBucketSpeedWithoutLoad = new SqlCommand($"select [Скорость_подъема/опускания_ковша_без_груза, м/с] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                double bucketSpeedWithoutLoad = Convert.ToDouble(cmdBucketSpeedWithoutLoad.ExecuteScalar());
                textBox_BucketSpeedWithoutLoad.Text = string.Format(Convert.ToString(bucketSpeedWithoutLoad));

                SqlCommand cmdAverageBucketFillingTime = new SqlCommand($"select [Среднее_время_заполнения_ковша_одной_тонной_груза, с] from Погрузчик where Марка_погрузчика = '{chosenModel}'",
                    connection);
                double averageBucketFillingTime = Convert.ToDouble(cmdAverageBucketFillingTime.ExecuteScalar());
                textBox_AverageBucketFillingTime.Text = string.Format(Convert.ToString(averageBucketFillingTime));

                SqlCommand cmdAverageDumpingTimeFromTheBucket = new SqlCommand($"select [Среднее_время_высыпания_одной_тонны_груза_из_ковша, с] from Погрузчик where Марка_погрузчика = '{chosenModel}'",
                    connection);
                double averageDumpingTimeFromTheBucket = Convert.ToDouble(cmdAverageDumpingTimeFromTheBucket.ExecuteScalar());
                textBox_AverageDumpingTimeFromTheBucket.Text = string.Format(Convert.ToString(averageDumpingTimeFromTheBucket));

                SqlCommand cmdLoaderID = new SqlCommand($"select [Код_погрузчика] from Погрузчик where Марка_погрузчика = '{chosenModel}'", connection);
                int loaderID = (int)cmdLoaderID.ExecuteScalar();
                textBox_LoaderID.Text = string.Format(Convert.ToString(loaderID));
            }
        }

        private void FormCalc_Load(object sender, EventArgs e)
        {

        }

        private void button_NewCalc_Click(object sender, EventArgs e)
        {
            textBox_ResReportName.Clear();
            textBox_ResWagonModel.Clear();
            textBox_ResWagonCapacity.Clear();
            textBox_ResSideHeight.Clear();
            textBox_ResNumberOfWagons.Clear();
            textBox_ResLoaderBrand.Clear();
            textBox_ResLoaderCapacity.Clear();
            textBox_ResBucketVolume.Clear();
            textBox_ResSpeedWithoutLoad.Clear();
            textBox_ResLoadedSpeed.Clear();
            textBox_ResBucketTipTime.Clear();
            textBox_ResBucketSpeedWithLoad.Clear();
            textBox_ResBucketSpeedWithoutLoad.Clear();
            textBox_ResAverageBucketFillingTime.Clear();
            textBox_ResAverageDumpingTimeFromTheBucket.Clear();
            textBox_ResL2.Clear();
            textBox_ResL3.Clear();
            textBox_ResL4.Clear();
            textBox_ResL5.Clear();
            textBox_LoaderCycle.Clear();
            textBox_TechnicalLoaderPerformance.Clear();
            textBox_LoaderPerformance.Clear();
            textBox_WagonServiceTime.Clear();
            textBox_TrainServiceTime.Clear();

            groupBox_Result.Visible = false;
            groupBox_RollingStock.Visible = true;
            groupBox_Loader.Visible = true;
            groupBox_Report.Visible = true;
            groupBox_Distance.Visible = true;
            button_SaveReport.Visible = false;
            button_NewCalc.Visible = false;
            button_GoCalc.Visible = true;
            button_Clear.Visible = true;

            textBox_ReportName.Clear();
            //comboBox_WagonModel.SelectedIndex = -1;
            textBox_WagonCapacity.Clear();
            textBox_SideHeight.Clear();
            textBox_NumberOfWagons.Clear();
            //comboBox_LoaderBrand.SelectedIndex = -1;
            textBox_LoaderCapacity.Clear();
            textBox_BucketVolume.Clear();
            textBox_SpeedWithoutLoad.Clear();
            textBox_LoadedSpeed.Clear();
            textBox_BucketTipTime.Clear();
            textBox_BucketSpeedWithLoad.Clear();
            textBox_BucketSpeedWithoutLoad.Clear();
            textBox_AverageBucketFillingTime.Clear();
            textBox_AverageDumpingTimeFromTheBucket.Clear();
            textBox_L2.Clear();
            textBox_L3.Clear();
            textBox_L4.Clear();
            textBox_L5.Clear();
        }

        private void button_SaveReport_Click(object sender, EventArgs e)
        {
            string reportName = textBox_ResReportName.Text;
            string loaderCycle = textBox_LoaderCycle.Text.Replace(",",".");
            string technicalLoaderPerformance = textBox_TechnicalLoaderPerformance.Text.Replace(",",".");
            string loaderPerformance = textBox_LoaderPerformance.Text.Replace(",",".");
            string wagonServiceTime = textBox_WagonServiceTime.Text.Replace(",",".");
            string trainServiceTime = textBox_TrainServiceTime.Text.Replace(",",".");
            string loaderID = textBox_LoaderID.Text;
            string wagonID = textBox_WagonID.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdGetLastID = new SqlCommand("select TOP 1 [Код_отчета] from Отчет order by [Код_отчета] DESC", connection);
                int lastID = (int)cmdGetLastID.ExecuteScalar();

                SqlCommand cmdSaveReport = new SqlCommand("insert into Отчет" +
                    "([Код_отчета], [Название_отчета], [Цикл_погрузчика, с], [Техническая_производительность_погрузчика, м^3], [Эксплуатационная_производительность_погрузчика, м^3], [Время_обслуживания_вагона, с], [Время_обслуживания_состава, с], [Код_погрузчика], [Код_вагона])" +
                    $"values('{lastID + 1}','{reportName}','{loaderCycle}','{technicalLoaderPerformance}','{loaderPerformance}','{wagonServiceTime}','{trainServiceTime}','{loaderID}','{wagonID}')", connection);
                cmdSaveReport.ExecuteNonQuery();
            }

            string folder = @"C:\Users\user\source\repos\CTPFL\Reports\";
            string fileName = "";

            if (textBox_ResReportName.Text.Length > 0)
            {
                fileName = string.Format(textBox_ResReportName.Text + ".txt");
            }
            else fileName = $"{DateTime.Today.ToShortDateString()}.txt";

            string fullPath = folder + fileName;
            string[] resultForPrint = {"Название отчета: ",textBox_ResReportName.Text,"\n",
                "Модель вагона: ",textBox_ResWagonModel.Text,"\n",
                "Грузоподъемность вагона, т: ",textBox_ResWagonCapacity.Text,"\n",
                "Высота борта вагона, м: ",textBox_ResSideHeight.Text,"\n",
                "Количество вагонов, шт: ",textBox_ResNumberOfWagons.Text,"\n",
                "Марка погрузчика: ",textBox_ResLoaderBrand.Text,"\n",
                "Грузоподъемность погрузчика, т: ",textBox_ResLoaderCapacity.Text,"\n",
                "Объем ковша, м^3: ",textBox_ResBucketVolume.Text,"\n",
                "Скорость без груза, м/с: ",textBox_ResSpeedWithoutLoad.Text,"\n",
                "Скорость с грузом, м/с: ",textBox_ResLoadedSpeed.Text,"\n",
                "Время запрокидывания ковша, с: ",textBox_ResBucketTipTime.Text,"\n",
                "Скорость ковша с грузом, м/с: ",textBox_ResBucketSpeedWithLoad.Text,"\n",
                "Скорость ковша без груза, м/с: ",textBox_ResBucketSpeedWithoutLoad.Text,"\n",
                "Среднее время заполнения ковша, с: ",textBox_ResAverageBucketFillingTime.Text,"\n",
                "Среднее время высыпания груза из ковша, с: ",textBox_ResAverageDumpingTimeFromTheBucket.Text,"\n",
                "Перемещение погрузчика при отъезде от штабеля груза, м: ",textBox_ResL2.Text,"\n",
                "Перемещение погрузчика при подъезде к вагону, м: ",textBox_ResL3.Text,"\n",
                "Перемещение погрузчика от вагона, м: ",textBox_ResL4.Text,"\n",
                "Перемещение погрузчика при движении к штабелю груза, м: ",textBox_ResL5.Text,"\n",
                "Цикл погрузчика, с: ",textBox_LoaderCycle.Text,"\n",
                "Техническая производительность погрузчика, м^3: ",textBox_TechnicalLoaderPerformance.Text,"\n",
                "Эксплуатационная производительность погрузчика, м^3: ",textBox_LoaderPerformance.Text,"\n",
                "Время обслуживания вагона, с: ",textBox_WagonServiceTime.Text,"\n",
                "Время обслуживания состава, с: ",textBox_TrainServiceTime.Text,"\n",
            };
            File.WriteAllLines(fullPath, resultForPrint);

            MessageBox.Show("Результаты расчета сохранены. Сформирован и сохранен текстовый файл в папке Reports приложения");

            System.Diagnostics.Process txt = new System.Diagnostics.Process();
            txt.StartInfo.FileName = "notepad.exe";
            txt.StartInfo.Arguments = fullPath;
            txt.Start();
        }
    }
}