﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTPFL
{
    public partial class FormReport : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        string connectionString = @"Data Source=DESKTOP-L5BOSMO;initial catalog=D_CTPFL;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;";
        string sql = "select * from Отчет";

        private FormMain _fmain;

        public FormReport(FormMain fmain)
        {
            InitializeComponent();

            _fmain = fmain;

            dataGridView_Report.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Report.DataSource = ds.Tables[0];
                dataGridView_Report.Columns["Код_отчета"].ReadOnly = true;
            }
        }

        private void button_Back_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _fmain.Visible = true;
            textBox_ReportName.Clear();
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView_Report.RowCount; i++)
            {
                dataGridView_Report.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView_Report.ColumnCount; j++)
                    if (dataGridView_Report.Rows[i].Cells[j].Value != null)
                        if (dataGridView_Report.Rows[i].Cells[j].Value.ToString().Contains(textBox_ReportName.Text))
                        {
                            dataGridView_Report.Rows[i].Selected = true;
                            break;
                        }
            }
        }

        private string folderName;

        private void button_SelectedFile_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                folderName = openFileDialog1.FileName;
                System.Diagnostics.Process txt = new System.Diagnostics.Process();
                txt.StartInfo.FileName = "notepad.exe";
                txt.StartInfo.Arguments = folderName;
                txt.Start();
            }
        }
    }
}