﻿namespace CTPFL
{
    partial class FormReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormReport));
            this.groupBox_Buttons = new System.Windows.Forms.GroupBox();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_Back = new System.Windows.Forms.Button();
            this.groupBox_SearchingReport = new System.Windows.Forms.GroupBox();
            this.textBox_ReportName = new System.Windows.Forms.TextBox();
            this.dataGridView_Report = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_SelectedFile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox_Buttons.SuspendLayout();
            this.groupBox_SearchingReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Report)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Buttons
            // 
            this.groupBox_Buttons.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox_Buttons.Controls.Add(this.button_Search);
            this.groupBox_Buttons.Controls.Add(this.button_Back);
            this.groupBox_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox_Buttons.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_Buttons.Location = new System.Drawing.Point(1328, 0);
            this.groupBox_Buttons.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Name = "groupBox_Buttons";
            this.groupBox_Buttons.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox_Buttons.Size = new System.Drawing.Size(250, 735);
            this.groupBox_Buttons.TabIndex = 3;
            this.groupBox_Buttons.TabStop = false;
            this.groupBox_Buttons.Text = "Выберите действие";
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Search.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Search.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Search.Location = new System.Drawing.Point(5, 65);
            this.button_Search.Margin = new System.Windows.Forms.Padding(0);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(240, 35);
            this.button_Search.TabIndex = 1;
            this.button_Search.Text = "Найти";
            this.button_Search.UseVisualStyleBackColor = false;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // button_Back
            // 
            this.button_Back.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Back.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Back.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Back.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Back.Location = new System.Drawing.Point(5, 30);
            this.button_Back.Margin = new System.Windows.Forms.Padding(0);
            this.button_Back.Name = "button_Back";
            this.button_Back.Size = new System.Drawing.Size(240, 35);
            this.button_Back.TabIndex = 0;
            this.button_Back.Text = "Вернуться в меню";
            this.button_Back.UseVisualStyleBackColor = false;
            this.button_Back.Click += new System.EventHandler(this.button_Back_Click);
            // 
            // groupBox_SearchingReport
            // 
            this.groupBox_SearchingReport.Controls.Add(this.textBox_ReportName);
            this.groupBox_SearchingReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_SearchingReport.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_SearchingReport.Location = new System.Drawing.Point(0, 0);
            this.groupBox_SearchingReport.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox_SearchingReport.Name = "groupBox_SearchingReport";
            this.groupBox_SearchingReport.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox_SearchingReport.Size = new System.Drawing.Size(1328, 102);
            this.groupBox_SearchingReport.TabIndex = 6;
            this.groupBox_SearchingReport.TabStop = false;
            this.groupBox_SearchingReport.Text = "Введите название отчета для поиска";
            // 
            // textBox_ReportName
            // 
            this.textBox_ReportName.Location = new System.Drawing.Point(13, 35);
            this.textBox_ReportName.Name = "textBox_ReportName";
            this.textBox_ReportName.Size = new System.Drawing.Size(292, 29);
            this.textBox_ReportName.TabIndex = 23;
            // 
            // dataGridView_Report
            // 
            this.dataGridView_Report.AllowUserToAddRows = false;
            this.dataGridView_Report.AllowUserToDeleteRows = false;
            this.dataGridView_Report.AllowUserToOrderColumns = true;
            this.dataGridView_Report.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView_Report.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Report.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView_Report.Location = new System.Drawing.Point(0, 102);
            this.dataGridView_Report.Name = "dataGridView_Report";
            this.dataGridView_Report.ReadOnly = true;
            this.dataGridView_Report.Size = new System.Drawing.Size(1328, 180);
            this.dataGridView_Report.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_SelectedFile);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(0, 282);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.Size = new System.Drawing.Size(1328, 93);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ввыберите отчет для открытия в папке Reports";
            // 
            // button_SelectedFile
            // 
            this.button_SelectedFile.BackColor = System.Drawing.SystemColors.ControlText;
            this.button_SelectedFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SelectedFile.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_SelectedFile.Location = new System.Drawing.Point(414, 32);
            this.button_SelectedFile.Margin = new System.Windows.Forms.Padding(0);
            this.button_SelectedFile.Name = "button_SelectedFile";
            this.button_SelectedFile.Size = new System.Drawing.Size(190, 30);
            this.button_SelectedFile.TabIndex = 2;
            this.button_SelectedFile.Text = "Выбрать отчет";
            this.button_SelectedFile.UseVisualStyleBackColor = false;
            this.button_SelectedFile.Click += new System.EventHandler(this.button_SelectedFile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.InitialDirectory = "C:\\Users\\user\\source\\repos\\CTPFL\\Reports\\";
            // 
            // FormReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1578, 735);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView_Report);
            this.Controls.Add(this.groupBox_SearchingReport);
            this.Controls.Add(this.groupBox_Buttons);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormReport";
            this.Text = "Сохраненные отчеты";
            this.groupBox_Buttons.ResumeLayout(false);
            this.groupBox_SearchingReport.ResumeLayout(false);
            this.groupBox_SearchingReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Report)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Buttons;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_Back;
        private System.Windows.Forms.GroupBox groupBox_SearchingReport;
        private System.Windows.Forms.TextBox textBox_ReportName;
        private System.Windows.Forms.DataGridView dataGridView_Report;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_SelectedFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}