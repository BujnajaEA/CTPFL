﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTPFL
{
    public partial class FormLoader : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        string connectionString = @"Data Source=DESKTOP-L5BOSMO;initial catalog=D_CTPFL;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;";
        string sql = "select * from Погрузчик";

        private FormMain _fmain;

        public FormLoader(FormMain fmain)
        {
            InitializeComponent();

            _fmain = fmain;

            dataGridView_Loader.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Loader.DataSource = ds.Tables[0];
                dataGridView_Loader.Columns["Код_погрузчика"].ReadOnly = true;
            }
        }

        private void button_Back_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _fmain.Visible = true;
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            string loaderBrand = textBox_LoaderBrand.Text;
            string loaderCapacity = textBox_LoaderCapacity.Text;
            string bucketVolume = textBox_BucketVolume.Text;
            string speedWithoutLoad = textBox_SpeedWithoutLoad.Text;
            string loadedSpeed = textBox_LoadedSpeed.Text;
            string bucketTipTime = textBox_BucketTipTime.Text;
            string bucketSpeedWithLoad = textBox_BucketSpeedWithLoad.Text;
            string bucketSpeedWithoutLoad = textBox_BucketSpeedWithoutLoad.Text;
            string averageBucketFillingTime = textBox_AverageBucketFillingTime.Text;
            string averageDumpingTimeFromTheBucket = textBox_AverageDumpingTimeFromTheBucket.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdGetLastID = new SqlCommand("select TOP 1 [Код_погрузчика] from Погрузчик order by [Код_погрузчика] DESC", connection);
                int lastID = (int)cmdGetLastID.ExecuteScalar();

                SqlCommand cmdAddLoader = new SqlCommand("insert into Погрузчик" + "([Код_погрузчика], [Марка_погрузчика], [Грузоподъемность_погрузчика, т], [Объем_ковша, м^3], [Скорость_без_груза, м/с], [Скорость_с_грузом, м/с], [Время_запрокидывания_ковша, с], [Скорость_подъема/опускания_ковша_с_грузом, м/с], [Скорость_подъема/опускания_ковша_без_груза, м/с], [Среднее_время_заполнения_ковша_одной_тонной_груза, с], [Среднее_время_высыпания_одной_тонны_груза_из_ковша, с])" +
                    $"values('{lastID + 1}','{loaderBrand}','{loaderCapacity}','{bucketVolume}','{speedWithoutLoad}','{loadedSpeed}','{bucketTipTime}','{bucketSpeedWithLoad}','{bucketSpeedWithoutLoad}','{averageBucketFillingTime}','{averageDumpingTimeFromTheBucket}')", connection);
                cmdAddLoader.ExecuteNonQuery();
                MessageBox.Show("Погрузчик добавлен");
            }
            textBox_LoaderBrand.Clear();
            textBox_LoaderCapacity.Clear();
            textBox_BucketVolume.Clear();
            textBox_SpeedWithoutLoad.Clear();
            textBox_LoadedSpeed.Clear();
            textBox_BucketTipTime.Clear();
            textBox_BucketSpeedWithLoad.Clear();
            textBox_BucketSpeedWithoutLoad.Clear();
            textBox_AverageBucketFillingTime.Clear();
            textBox_AverageDumpingTimeFromTheBucket.Clear();

            dataGridView_Loader.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Loader.DataSource = ds.Tables[0];
                // делаем недоступным столбец id для изменения
                dataGridView_Loader.Columns["Код_погрузчика"].ReadOnly = true;
            }
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            string loaderBrand = textBox_LoaderBrand.Text;
            string loaderCapacity = textBox_LoaderCapacity.Text;
            string bucketVolume = textBox_BucketVolume.Text;
            string speedWithoutLoad = textBox_SpeedWithoutLoad.Text;
            string loadedSpeed = textBox_LoadedSpeed.Text;
            string bucketTipTime = textBox_BucketTipTime.Text;
            string bucketSpeedWithLoad = textBox_BucketSpeedWithLoad.Text;
            string bucketSpeedWithoutLoad = textBox_BucketSpeedWithoutLoad.Text;
            string averageBucketFillingTime = textBox_AverageBucketFillingTime.Text;
            string averageDumpingTimeFromTheBucket = textBox_AverageDumpingTimeFromTheBucket.Text;

            string selectedLoaderID = dataGridView_Loader.CurrentCell.Value.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdEditLoader = new SqlCommand("update Погрузчик" +
                $" set [Марка_погрузчика] = '{loaderBrand}', [Грузоподъемность_погрузчика, т] = '{loaderCapacity}', [Объем_ковша, м^3] = '{bucketVolume}', [Скорость_без_груза, м/с] = '{speedWithoutLoad}', [Скорость_с_грузом, м/с] = '{loadedSpeed}', [Время_запрокидывания_ковша, с] = '{bucketTipTime}', [Скорость_подъема/опускания_ковша_с_грузом, м/с] = '{bucketSpeedWithLoad}', [Скорость_подъема/опускания_ковша_без_груза, м/с] = '{bucketSpeedWithoutLoad}', [Среднее_время_заполнения_ковша_одной_тонной_груза, с] = '{averageBucketFillingTime}', [Среднее_время_высыпания_одной_тонны_груза_из_ковша, с] = '{averageDumpingTimeFromTheBucket}'" +
                $" where [Код_погрузчика] = '{selectedLoaderID}'", connection);
                cmdEditLoader.ExecuteNonQuery();
                MessageBox.Show("Данные выбранного погрузчика отредактированы");
            }
            
            textBox_LoaderBrand.Clear();
            textBox_LoaderCapacity.Clear();
            textBox_BucketVolume.Clear();
            textBox_SpeedWithoutLoad.Clear();
            textBox_LoadedSpeed.Clear();
            textBox_BucketTipTime.Clear();
            textBox_BucketSpeedWithLoad.Clear();
            textBox_BucketSpeedWithoutLoad.Clear();
            textBox_AverageBucketFillingTime.Clear();
            textBox_AverageDumpingTimeFromTheBucket.Clear();

            dataGridView_Loader.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Loader.DataSource = ds.Tables[0];
                // делаем недоступным столбец id для изменения
                dataGridView_Loader.Columns["Код_погрузчика"].ReadOnly = true;
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            string selectedLoaderID = dataGridView_Loader.CurrentCell.Value.ToString();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmdDeleteLoader = new SqlCommand($"delete from Погрузчик where [Код_погрузчика] = {selectedLoaderID}", connection);
                cmdDeleteLoader.ExecuteNonQuery();
                MessageBox.Show($"Вы удалили погрузчик с кодом {selectedLoaderID}.");
            }

            dataGridView_Loader.DataSource = new object();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView_Loader.DataSource = ds.Tables[0];
                // делаем недоступным столбец id для изменения
                dataGridView_Loader.Columns["Код_погрузчика"].ReadOnly = true;
            }
        }
    }
}
