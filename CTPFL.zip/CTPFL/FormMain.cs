﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTPFL
{
    public partial class FormMain : Form
    {
        private FormCalc fcalc;
        private FormLoader fload;
        private FormReport frep;
        private FormWagon fwag;

        public FormMain()
        {
            InitializeComponent();

            fcalc = new FormCalc(this) { Visible = false };
            fload = new FormLoader(this) { Visible = false };
            frep = new FormReport(this) { Visible = false };
            fwag = new FormWagon(this) { Visible = false };
        }

        private void button_Calc_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            fcalc.Visible = true;
        }

        private void button_Loader_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            fload.Visible = true;
        }

        private void button_Report_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            frep.Visible = true;
        }

        private void button_Wagon_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            fwag.Visible = true;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }
    }
}
